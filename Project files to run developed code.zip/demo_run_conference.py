from __future__ import annotations

from pathlib import Path
import json
import os

import pandas as pd
import torch

from marl_utility_calibration.agents import DeepAgentConfig, UtilitySpec
from marl_utility_calibration.calibration import PopulationCandidate, evaluate_candidate
from marl_utility_calibration.envs import (
    build_dictator_game_env,
    build_public_goods_env,
    build_repeated_prisoners_dilemma_env,
    build_repeated_ultimatum_env,
    build_sequential_trust_game_env,
)
from marl_utility_calibration.predictive_optimality import (
    PredictiveOptimalConfig,
    run_predictive_optimality_benchmark,
)


def _serialize_candidate(candidate: PopulationCandidate) -> dict:
    return {
        "name": candidate.name,
        "utility_specs": [
            {"family": spec.family, "params": spec.params}
            for spec in candidate.utility_specs
        ],
    }


def main():
    outdir = Path("outputs_predictive_optimality")
    outdir.mkdir(exist_ok=True)

    train_envs = {
        "rpd": lambda: build_repeated_prisoners_dilemma_env(horizon=8),
        "ult": lambda: build_repeated_ultimatum_env(rounds=6),
    }
    val_envs = {
        "pgg": lambda: build_public_goods_env(n_agents=3, horizon=6, multiplier=2.5),
        "dictator": lambda: build_dictator_game_env(rounds=6),
    }
    test_envs = {
        "rpd_shift": lambda: build_repeated_prisoners_dilemma_env(horizon=10, benefit=3.4),
        "ult_shift": lambda: build_repeated_ultimatum_env(rounds=7),
        "pgg_shift": lambda: build_public_goods_env(n_agents=3, horizon=7, multiplier=2.8),
        "dictator_shift": lambda: build_dictator_game_env(rounds=7, offer_levels=13),
        "trust_shift": lambda: build_sequential_trust_game_env(rounds=7, multiplier=3.2),
    }

    deep_cfg = DeepAgentConfig(
        hidden_sizes=(64, 64),
        warmup_steps=128,
        replay_size=6000,
        batch_size=128,
        epsilon_decay=1500,
        device="auto",
        use_amp=True,
        compile_model=torch.cuda.is_available(),
        parallel_envs=4 if torch.cuda.is_available() else 1,
    )

    # Use a homogeneous target population so recovery is evaluated within the same
    # representational scope searched by the benchmark methods.
    truth_spec = UtilitySpec(
        "social_tradeoff",
        {"selfish_weight": 1.0, "altruism_weight": 1.0, "other_payoff_aggregation": "mean"},
    )
    target_candidate = PopulationCandidate(
        name="predictive_truth_homogeneous_social_tradeoff",
        utility_specs=[truth_spec, truth_spec, truth_spec],
    )

    run_ablations = os.environ.get("RUN_ABLATIONS", "0").strip().lower() in {"1", "true", "yes", "y"}

    cfg = PredictiveOptimalConfig(
        n_restarts=1,
        n_bootstrap=20,
        top_k_per_method=2,
        train_episodes=500,
        complexity_penalty=0.02,
        exhaustive_max_terms=1,
        finalist_repeats=20,
        finalist_eval_min_episodes=500,
        bootstrap_eval_min_episodes=500,
        run_ablation_sweep=run_ablations,
        greedy_tail_frac=0.3,
        finalist_count=3,
    )

    meta = {
        "target_generation_episodes": 500,
        "benchmark_config": {
            "n_restarts": cfg.n_restarts,
            "n_bootstrap": cfg.n_bootstrap,
            "top_k_per_method": cfg.top_k_per_method,
            "train_episodes": cfg.train_episodes,
            "complexity_penalty": cfg.complexity_penalty,
            "finalist_repeats": cfg.finalist_repeats,
            "finalist_eval_min_episodes": cfg.finalist_eval_min_episodes,
            "bootstrap_eval_min_episodes": cfg.bootstrap_eval_min_episodes,
            "greedy_tail_frac": cfg.greedy_tail_frac,
            "exhaustive_max_terms": cfg.exhaustive_max_terms,
            "exhaustive_terms": list(cfg.exhaustive_terms),
            "exhaustive_weight_grid": list(cfg.exhaustive_weight_grid),
            "compute_budget_note": "Finalist repeats and bootstrap significance rerun held-out test evaluations with a minimum episode budget that can exceed train_episodes. See finalist_eval_min_episodes and bootstrap_eval_min_episodes.",
            "run_ablation_sweep": cfg.run_ablation_sweep,
        },
        "deep_config": {
            "hidden_sizes": list(deep_cfg.hidden_sizes),
            "warmup_steps": deep_cfg.warmup_steps,
            "replay_size": deep_cfg.replay_size,
            "batch_size": deep_cfg.batch_size,
            "epsilon_decay": deep_cfg.epsilon_decay,
            "device": deep_cfg.device,
            "use_amp": deep_cfg.use_amp,
            "compile_model": deep_cfg.compile_model,
        },
    }
    (outdir / "conference_config.json").write_text(json.dumps(meta, indent=2))
    (outdir / "target_truth.json").write_text(json.dumps(_serialize_candidate(target_candidate), indent=2))

    print("[conference] generating target moments", flush=True)
    target_moments = {}
    for env_name, builder in {**train_envs, **val_envs, **test_envs}.items():
        print(f"[conference] target env={env_name} start", flush=True)
        target_moments.update(
            evaluate_candidate(
                target_candidate,
                {env_name: builder},
                train_episodes=500,
                seed=123,
                agent_kind="deep",
                deep_config=deep_cfg,
                verbose=True,
                greedy_tail_frac=cfg.greedy_tail_frac,
            )
        )
        print(f"[conference] target env={env_name} done total_target_moments={len(target_moments)}", flush=True)

    print("[conference] running predictive optimality benchmark", flush=True)
    out = run_predictive_optimality_benchmark(
        target_moments=target_moments,
        train_env_builders=train_envs,
        validation_env_builders=val_envs,
        test_env_builders=test_envs,
        n_agents=3,
        config=cfg,
        seed=42,
        agent_kind="deep",
        deep_config=deep_cfg,
    )

    selected_signature = out.selected_signature
    selected_payload = {
        "selected_candidate": out.selected_candidate,
        "selected_signature": selected_signature,
        "selection_source": "run_predictive_optimality_benchmark_two_stage",
        "note": "Search and final evaluation are separated: finalists are rerun independently for repeated test statistics, pairwise tests, and ablations.",
    }
    (outdir / "selected_candidate.json").write_text(json.dumps(selected_payload, indent=2))

    pd.DataFrame([target_moments]).to_csv(outdir / "target_moments.csv", index=False)
    out.overall_ranking.to_csv(outdir / "overall_ranking.csv", index=False)
    out.bootstrap_summary.to_csv(outdir / "bootstrap_summary.csv", index=False)
    out.significance_table.to_csv(outdir / "significance_table.csv", index=False)
    out.exhaustive_restricted_ranking.to_csv(outdir / "exhaustive_restricted_ranking.csv", index=False)
    out.cross_method_winners.to_csv(outdir / "cross_method_winners.csv", index=False)
    out.agreement_summary.to_csv(outdir / "agreement_summary.csv", index=False)
    out.restart_winner_frequency.to_csv(outdir / "restart_winner_frequency.csv", index=False)
    out.method_consensus_summary.to_csv(outdir / "method_consensus_summary.csv", index=False)
    out.finalist_summary.to_csv(outdir / "finalist_summary.csv", index=False)
    out.finalist_repeated_test.to_csv(outdir / "finalist_repeated_test.csv", index=False)
    out.finalist_pairwise_tests.to_csv(outdir / "finalist_pairwise_tests.csv", index=False)
    out.finalist_winner_frequency.to_csv(outdir / "finalist_winner_frequency.csv", index=False)
    out.restart_variance_summary.to_csv(outdir / "restart_variance_summary.csv", index=False)
    if cfg.run_ablation_sweep:
        out.ablation_summary.to_csv(outdir / "ablation_summary.csv", index=False)
    out.rich_class_summary.to_csv(outdir / "rich_class_summary.csv", index=False)
    out.optimality_certificates.to_csv(outdir / "optimality_certificates.csv", index=False)
    (outdir / "approximate_predictive_optimality_definition.txt").write_text(out.definition)
    (outdir / "rich_class_interpretation.txt").write_text(out.rich_class_interpretation)

    print(f"[conference] run_ablation_sweep={cfg.run_ablation_sweep}", flush=True)
    print(out.definition)
    print(out.rich_class_interpretation)
    print("\nSelected predictively optimal candidate:", out.selected_candidate)
    print("\nTop overall ranking")
    print(out.overall_ranking.head(10).to_string(index=False))
    print("\nTop certificates")
    print(out.optimality_certificates.head(10).to_string(index=False))
    print("\nSaved outputs to", outdir.resolve())


if __name__ == "__main__":
    main()
