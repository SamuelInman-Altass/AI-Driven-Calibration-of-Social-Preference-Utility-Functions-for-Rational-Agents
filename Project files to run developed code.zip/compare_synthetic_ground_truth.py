from __future__ import annotations

from pathlib import Path
import json
import pandas as pd


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text())


def main():
    outdir = Path("outputs_predictive_optimality")
    if not outdir.exists():
        raise FileNotFoundError("outputs_predictive_optimality not found. Run demo_run_conference.py first.")

    selected_path = outdir / "selected_candidate.json"
    truth_path = outdir / "target_truth.json"
    ranking_path = outdir / "overall_ranking.csv"
    certs_path = outdir / "optimality_certificates.csv"
    ref_path = outdir / "exhaustive_restricted_ranking.csv"
    config_path = outdir / "conference_config.json"

    missing = [str(p.name) for p in [selected_path, truth_path, ranking_path, certs_path, ref_path, config_path] if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing required artifacts: " + ", ".join(missing))

    selected = _load_json(selected_path)
    truth = _load_json(truth_path)
    config = _load_json(config_path)
    ranking = pd.read_csv(ranking_path)
    certs = pd.read_csv(certs_path)
    restricted = pd.read_csv(ref_path)

    top = ranking.iloc[0].to_dict() if not ranking.empty else {}
    top_cert = certs.iloc[0].to_dict() if not certs.empty else {}
    ref_top = restricted.iloc[0].to_dict() if not restricted.empty else {}

    truth_families = [item.get("family", "") for item in truth.get("utility_specs", [])]
    selected_name = selected.get("selected_candidate") or top.get("candidate")
    selected_signature = selected.get("selected_signature") or top.get("signature")

    summary = {
        "selection_source": selected.get("selection_source", "artifacts_only"),
        "selected_candidate": selected_name,
        "selected_signature": selected_signature,
        "selected_family": top.get("family"),
        "selected_predictive_optimal_score": top.get("predictive_optimal_score"),
        "selected_mean_validation_loss": top.get("mean_validation_loss"),
        "selected_mean_test_loss": top.get("mean_test_loss"),
        "selected_mean_complexity": top.get("mean_complexity"),
        "selected_optimality_status": top_cert.get("optimality_status"),
        "selected_scope": top_cert.get("certificate_scope"),
        "restricted_reference_candidate": ref_top.get("candidate"),
        "restricted_reference_signature": ref_top.get("signature"),
        "restricted_reference_score": ref_top.get("predictive_optimal_score"),
        "restricted_reference_mean_test_loss": ref_top.get("mean_test_loss"),
        "target_truth_name": truth.get("name"),
        "target_truth_families": ";".join(truth_families),
        "target_truth_num_specs": len(truth.get("utility_specs", [])),
        "benchmark_train_episodes": config.get("benchmark_config", {}).get("train_episodes"),
        "benchmark_n_restarts": config.get("benchmark_config", {}).get("n_restarts"),
        "benchmark_n_bootstrap": config.get("benchmark_config", {}).get("n_bootstrap"),
        "comparison_mode": "artifact_only",
        "note": "This script does not rerun search or RL. It compares the selected rich-class winner to the saved synthetic truth metadata and saved restricted reference artifacts. The conference demo now uses a homogeneous target population so recovery is evaluated within the searched model class.",
    }

    selected_family = top.get("family")
    selected_family_values = [str(selected_family)] if selected_family is not None else []
    family_overlap = sorted(set(truth_families) & set(selected_family_values))
    family_compare = pd.DataFrame([
        {"family": fam, "present_in_target_truth": fam in truth_families, "selected_family": selected_family, "selected_matches_family": fam == selected_family}
        for fam in sorted(set(truth_families + selected_family_values))
    ])

    summary_df = pd.DataFrame([summary])
    summary_df.to_csv(outdir / "synthetic_truth_comparison.csv", index=False)
    family_compare.to_csv(outdir / "synthetic_truth_family_comparison.csv", index=False)

    print("Artifact-only synthetic truth comparison")
    print(summary_df.to_string(index=False))
    print("\nFamily-level comparison")
    print(family_compare.to_string(index=False))
    print("\nSaved", (outdir / "synthetic_truth_comparison.csv").resolve())
    print("Saved", (outdir / "synthetic_truth_family_comparison.csv").resolve())


if __name__ == "__main__":
    main()
