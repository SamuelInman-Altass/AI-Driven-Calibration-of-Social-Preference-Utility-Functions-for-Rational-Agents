This is a tighter Colab-scale build with the same methods enabled but smaller default budgets.

# Colab-scale default build

This package keeps the same methodology but uses smaller default search budgets so the main experiment is practical in an interactive Colab session.

# Multi-Agent Utility Calibration with PettingZoo

This project upgrades the original synthetic bargaining notebook into a real multi-agent simulation workflow that runs with **PettingZoo** in **Google Colab** or **VS Code**.

It includes:
- canonical multi-agent environments
  - repeated prisoner's dilemma
  - ultimatum game
  - public goods game
- heterogeneous agent populations
  - selfish utility
  - altruism utility
  - Fehr-Schmidt inequity aversion
- tabular multi-agent RL agents
- behavior trackers that produce calibration targets
- a calibration loop that fits a population mix to observed behavior moments

## Quick start in Colab

```python
!pip install -q pettingzoo shimmy gymnasium numpy pandas matplotlib
!python demo_run.py
```

## Quick start in VS Code

```bash
python -m venv .venv
source .venv/bin/activate   # on Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python demo_run.py
```

## Files

- `marl_utility_calibration/envs.py` — PettingZoo environments
- `marl_utility_calibration/agents.py` — utility models and Q-learning agents
- `marl_utility_calibration/tracking.py` — moment extraction and calibration targets
- `marl_utility_calibration/calibration.py` — fit population mixes to target moments
- `demo_run.py` — end-to-end demo

## Design notes

These environments use the real **PettingZoo ParallelEnv API**. They are intentionally compact so they are easy to inspect and modify.

The calibration workflow is:
1. define a candidate population of utility models
2. simulate repeated interaction with RL agents
3. extract behavior moments from logs
4. compare those moments to observed targets
5. search for the best-fitting utility mix

## Suggested next extensions

- replace tabular Q-learning with DQN/PPO for richer state spaces
- add repeated ultimatum with memory and reputation
- fit utility parameters continuously instead of via a grid
- swap synthetic targets for lab or field data summaries


## Deep RL extension

This project now includes a PyTorch DQN-based multi-agent pipeline:
- neural-network policies (`DeepQAgent`)
- replay buffer + target network updates
- richer state spaces in repeated PD, repeated ultimatum, and public-goods games
- `demo_run_deep.py` for a deep-RL calibration demo

Run locally after installing dependencies:

```bash
pip install -r requirements.txt
python demo_run_deep.py
```


## Utility families

This project now distinguishes between three related ideas:
- `selfish`: maximize own payoff only
- `social_tradeoff`: explicit weighted balance of selfishness and selflessness via `selfish_weight` and `altruism_weight`
- `inequity_aversion` (alias `fehr_schmidt`): own payoff minus Fehr-Schmidt style inequity penalties

That makes the code match proposal language more closely: rewards can be defined by varying degrees of selfishness and altruism, while inequity aversion remains a separate objective family rather than being treated as the same thing.


## Empirical calibration path

The project now includes CSV ingestion so you can calibrate candidate utility populations to behavioral data instead of only synthetic targets.

Supported CSV formats:
- `moment_key,value`
- `env,moment,value`
- trial-level logs with an `env` column and behavioral columns such as `cooperated`, `offer_frac`, `accepted`, `contribution_frac`

Files:
- `sample_empirical_targets.csv` — simple moment targets
- `sample_empirical_logs.csv` — trial-level example logs
- `demo_run_empirical.py` — calibrate candidate populations to a CSV file

Example:

```bash
python demo_run_empirical.py
```


Additional demo:
- `python demo_run_symbolic.py` runs symbolic/compositional utility search with nonlinear operators and interactions.


## Integrated symbolic + neural utility search

This project now includes an integrated outer-loop search layer:
- **beam symbolic search** over a richer expression grammar
- **evolutionary symbolic search** with mutation/selection
- **neural utility baseline** optimized by outer-loop evolution
- **distillation** from the best neural utility into a sparse symbolic utility

New files:
- `marl_utility_calibration/integrated_search.py`
- `marl_utility_calibration/neural_utility.py`
- `demo_run_integrated.py`

Run:

```bash
python demo_run_integrated.py
```


## Current entry point

Use `demo_run_predictive_optimality.py` as the main experiment script. Earlier demo scripts were removed from this cleaned package.


## GPU notes

This project now auto-selects CUDA when available for deep-RL agents. On Colab, set **Runtime > Change runtime type > GPU** before running.

The PyTorch path now uses:
- automatic device selection (`device="auto"`)
- mixed precision on CUDA
- `torch.compile(...)` when available
- TF32-enabled matmul/cuDNN on NVIDIA GPUs

The biggest remaining bottleneck is PettingZoo environment stepping, which still runs on CPU. GPU acceleration mainly speeds up the DQN forward/backward passes.


## Conference-scale experiment

Run the larger-budget experiment with:

```bash
python demo_run_conference.py
```

This writes outputs to `outputs_predictive_optimality/` including:
- `overall_ranking.csv`
- `optimality_certificates.csv`
- `cross_method_winners.csv`
- `target_truth.json`
- `selected_candidate.json`

Inspect the saved CSVs with:

```bash
python inspect_outputs.py
```

Compare the selected rich-class winner against the known synthetic ground truth with:

```bash
python compare_synthetic_ground_truth.py
```

Recommended hardware: a dedicated GPU instance rather than free Colab.


## UltimatumEnv migration note
The repeated ultimatum environment now uses metadata name `ultimatum_repeated_v2` and a 4-dimensional observation layout instead of the older 5-dimensional layout. Older saved models/results should be rerun rather than reused.


## Compute budget note

The conference benchmark uses `train_episodes` for the main search, but finalist repeated-test evaluation and bootstrap significance rerun held-out test evaluations with minimum episode floors (`finalist_eval_min_episodes` and `bootstrap_eval_min_episodes`, default 80). This is intentional to stabilize post-selection comparisons, but it can make the total compute budget materially larger than `train_episodes` alone suggests.

The conference demo also uses a homogeneous target population so recovery is evaluated inside the same searched model class.
