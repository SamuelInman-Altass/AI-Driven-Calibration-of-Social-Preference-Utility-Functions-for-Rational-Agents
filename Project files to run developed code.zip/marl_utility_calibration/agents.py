from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any, Deque, Dict, Iterable, List, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .utility_expressions import active_expression_count, evaluate_expression
from .neural_utility import forward_neural_utility


@dataclass(frozen=True)
class UtilitySpec:
    family: str
    params: Dict[str, Any]


class UtilityModel:
    """Utility families used to define agent rationality.

    Supported families:
    - selfish: maximize only own payoff
    - altruism: own payoff plus a weighted sum of others' payoffs
    - social_tradeoff: weighted balance of selfishness and selflessness
    - inequity_aversion / fehr_schmidt: inequity penalties on payoff gaps
    - compositional: sparse weighted combination of reusable utility primitives
    """

    @staticmethod
    def feature_map(own_payoff: float, others_payoffs: Iterable[float], context: Dict[str, float] | None = None) -> Dict[str, float]:
        others = np.asarray(list(others_payoffs), dtype=float)
        mean_other = float(np.mean(others)) if others.size else 0.0
        total_other = float(np.sum(others)) if others.size else 0.0
        disadv = float(np.maximum(others - own_payoff, 0.0).sum()) if others.size else 0.0
        adv = float(np.maximum(own_payoff - others, 0.0).sum()) if others.size else 0.0
        min_other = float(np.min(others)) if others.size else 0.0
        max_other = float(np.max(others)) if others.size else 0.0
        inequality = float(np.mean(np.abs(others - own_payoff))) if others.size else 0.0
        ctx = context or {}
        return {
            "own_payoff": float(own_payoff),
            "others_mean": mean_other,
            "others_sum": total_other,
            "others_min": min_other,
            "others_max": max_other,
            "disadv_ineq": disadv,
            "adv_ineq": adv,
            "inequality_mean_abs": inequality,
            "accepted": float(ctx.get("accepted", 0.0)),
            "cooperated": float(ctx.get("cooperated", 0.0)),
            "contribution_frac": float(ctx.get("contribution_frac", 0.0)),
            "offer_frac": float(ctx.get("offer_frac", 0.0)),
        }

    @staticmethod
    def utility(family: str, own_payoff: float, others_payoffs: Iterable[float], params: Dict[str, Any]) -> float:
        others = np.asarray(list(others_payoffs), dtype=float)
        mean_other = float(np.mean(others)) if others.size else 0.0

        if family == "selfish":
            selfish_weight = float(params.get("selfish_weight", 1.0))
            return float(selfish_weight * own_payoff)

        if family == "altruism":
            gamma = float(params.get("gamma", 0.3))
            return float(own_payoff + gamma * np.sum(others))

        if family == "social_tradeoff":
            selfish_weight = float(params.get("selfish_weight", 1.0))
            altruism_weight = float(params.get("altruism_weight", 0.0))
            aggregation = str(params.get("other_payoff_aggregation", "mean"))
            other_term = mean_other if aggregation == "mean" else float(np.sum(others))
            return float(selfish_weight * own_payoff + altruism_weight * other_term)

        if family in {"fehr_schmidt", "inequity_aversion"}:
            alpha = float(params.get("alpha", 0.8))
            beta = float(params.get("beta", 0.2))
            selfish_weight = float(params.get("selfish_weight", 1.0))
            disadv = np.maximum(others - own_payoff, 0.0).sum()
            adv = np.maximum(own_payoff - others, 0.0).sum()
            return float(selfish_weight * own_payoff - alpha * disadv - beta * adv)

        if family == "compositional":
            weights = params.get("weights", {})
            features = UtilityModel.feature_map(own_payoff, others, params.get("context", {}))
            return float(sum(float(weights.get(term, 0.0)) * features.get(term, 0.0) for term in weights))

        if family == "symbolic_compositional":
            weights = params.get("weights", {})
            features = UtilityModel.feature_map(own_payoff, others, params.get("context", {}))
            total = 0.0
            for expr, weight in weights.items():
                total += float(weight) * evaluate_expression(expr, features)
            return float(total)

        if family == "neural_utility":
            features = UtilityModel.feature_map(own_payoff, others, params.get("context", {}))
            return float(forward_neural_utility(features, params))

        if family == "gp_symbolic":
            from .tree_gp import eval_tree
            features = UtilityModel.feature_map(own_payoff, others, params.get("context", {}))
            return float(eval_tree(params.get("tree", {}), features))

        raise ValueError(f"Unknown utility family: {family}")

    @staticmethod
    def complexity(spec: UtilitySpec) -> int:
        if spec.family == "compositional":
            weights = spec.params.get("weights", {})
            return int(sum(1 for _, v in weights.items() if abs(float(v)) > 1e-12))
        if spec.family == "symbolic_compositional":
            weights = spec.params.get("weights", {})
            return active_expression_count(weights)
        if spec.family == "neural_utility":
            n_params = 0
            for w in spec.params.get("weights", []):
                n_params += int(np.asarray(w, dtype=float).size)
            for b in spec.params.get("biases", []):
                n_params += int(np.asarray(b, dtype=float).size)
            return n_params
        if spec.family == "gp_symbolic":
            from .tree_gp import tree_complexity
            return tree_complexity(spec.params.get("tree", {}))
        if spec.family in {"selfish", "altruism", "social_tradeoff", "fehr_schmidt", "inequity_aversion"}:
            return int(len(spec.params) if spec.params else 1)
        return 1


@dataclass
class AgentConfig:
    epsilon: float = 0.15
    alpha: float = 0.2
    gamma: float = 0.95
    bins: int = 10


class QLearningAgent:
    def __init__(self, name: str, utility_spec: UtilitySpec, n_actions: int, config: AgentConfig | None = None, seed: int = 0, obs_high: np.ndarray | None = None):
        self.name = name
        self.utility_spec = utility_spec
        self.n_actions = n_actions
        self.config = config or AgentConfig()
        self.q_table: Dict[Tuple[int, ...], np.ndarray] = {}
        self.rng = np.random.default_rng(seed)
        self._obs_high = None if obs_high is None else np.asarray(obs_high, dtype=float).ravel()

    def discretize(self, obs: np.ndarray) -> Tuple[int, ...]:
        obs = np.asarray(obs, dtype=float).ravel()
        if self._obs_high is None or self._obs_high.shape != obs.shape:
            high = np.ones_like(obs, dtype=float)
        else:
            high = np.asarray(self._obs_high, dtype=float)
        safe_high = np.where(np.isfinite(high) & (high > 1e-8), high, 1.0)
        clipped = np.clip(obs, 0.0, safe_high)
        normalized = np.divide(clipped, safe_high, out=np.zeros_like(clipped, dtype=float), where=safe_high > 1e-8)
        normalized = np.clip(normalized, 0.0, 1.0)
        return tuple(np.floor(normalized * (self.config.bins - 1e-9)).astype(int).tolist())

    def _ensure_state(self, state: Tuple[int, ...]):
        if state not in self.q_table:
            self.q_table[state] = np.zeros(self.n_actions, dtype=float)

    def act(self, obs: np.ndarray, greedy: bool = False) -> int:
        state = self.discretize(obs)
        self._ensure_state(state)
        if (not greedy) and self.rng.random() < self.config.epsilon:
            return int(self.rng.integers(self.n_actions))
        return int(np.argmax(self.q_table[state]))

    def utility_reward(self, raw_rewards: Dict[str, float], info: Dict[str, float] | None = None) -> float:
        own = raw_rewards[self.name]
        others = [reward for agent, reward in raw_rewards.items() if agent != self.name]
        params = dict(self.utility_spec.params)
        if self.utility_spec.family in {"compositional", "symbolic_compositional"}:
            params["context"] = info or {}
        return UtilityModel.utility(self.utility_spec.family, own, others, params)

    def update(self, obs: np.ndarray, action: int, utility_reward: float, next_obs: np.ndarray, done: bool):
        state = self.discretize(obs)
        next_state = self.discretize(next_obs)
        self._ensure_state(state)
        self._ensure_state(next_state)
        next_max = 0.0 if done else float(np.max(self.q_table[next_state]))
        target = utility_reward + self.config.gamma * next_max
        self.q_table[state][action] += self.config.alpha * (target - self.q_table[state][action])


@dataclass
class DeepAgentConfig:
    gamma: float = 0.99
    epsilon_start: float = 1.0
    epsilon_end: float = 0.05
    epsilon_decay: int = 5000
    learning_rate: float = 1e-3
    hidden_sizes: Tuple[int, ...] = (128, 128)
    replay_size: int = 20000
    batch_size: int = 64
    target_update_interval: int = 200
    warmup_steps: int = 250
    train_interval: int = 1
    gradient_clip: float = 5.0
    device: str = "auto"
    use_amp: bool = True
    compile_model: bool = False
    torch_num_threads: int | None = None
    parallel_envs: int = 1


def resolve_torch_device(device: str = "auto") -> torch.device:
    requested = (device or "auto").lower()
    if requested == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        if getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    return torch.device(device)


def configure_torch_runtime(device: torch.device, num_threads: int | None = None) -> None:
    if num_threads is not None and device.type == "cpu":
        torch.set_num_threads(num_threads)
    torch.set_float32_matmul_precision("high")
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True


class ReplayBuffer:
    def __init__(self, capacity: int, seed: int = 0):
        self.buffer: Deque[Tuple[np.ndarray, int, float, np.ndarray, bool]] = deque(maxlen=capacity)
        self.rng = np.random.default_rng(seed)

    def add(self, obs: np.ndarray, action: int, reward: float, next_obs: np.ndarray, done: bool):
        self.buffer.append((
            np.asarray(obs, dtype=np.float32).copy(),
            int(action),
            float(reward),
            np.asarray(next_obs, dtype=np.float32).copy(),
            bool(done),
        ))

    def sample_numpy(self, batch_size: int):
        if batch_size > len(self.buffer):
            raise ValueError(f"Cannot sample batch_size={batch_size} from replay buffer of size {len(self.buffer)}")
        idx = self.rng.choice(len(self.buffer), size=batch_size, replace=False)
        batch = [self.buffer[i] for i in idx]
        obs, actions, rewards, next_obs, dones = zip(*batch)
        return (
            np.stack(obs),
            np.asarray(actions, dtype=np.int64),
            np.asarray(rewards, dtype=np.float32),
            np.stack(next_obs),
            np.asarray(dones, dtype=np.float32),
        )

    def sample_tensors(self, batch_size: int, device: torch.device):
        obs_b, act_b, rew_b, next_obs_b, done_b = self.sample_numpy(batch_size)
        if device.type == "cuda":
            obs_b = torch.from_numpy(obs_b).pin_memory().to(device=device, non_blocking=True)
            act_b = torch.from_numpy(act_b).pin_memory().to(device=device, non_blocking=True).unsqueeze(1)
            rew_b = torch.from_numpy(rew_b).pin_memory().to(device=device, non_blocking=True)
            next_obs_b = torch.from_numpy(next_obs_b).pin_memory().to(device=device, non_blocking=True)
            done_b = torch.from_numpy(done_b).pin_memory().to(device=device, non_blocking=True)
            return obs_b, act_b, rew_b, next_obs_b, done_b
        return (
            torch.as_tensor(obs_b, device=device),
            torch.as_tensor(act_b, device=device).unsqueeze(1),
            torch.as_tensor(rew_b, device=device),
            torch.as_tensor(next_obs_b, device=device),
            torch.as_tensor(done_b, device=device),
        )

    def __len__(self):
        return len(self.buffer)


class MLPQNetwork(nn.Module):
    def __init__(self, input_dim: int, n_actions: int, hidden_sizes: Tuple[int, ...]):
        super().__init__()
        layers: List[nn.Module] = []
        prev = input_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(prev, h))
            layers.append(nn.ReLU())
            prev = h
        layers.append(nn.Linear(prev, n_actions))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class DeepQAgent:
    def __init__(
        self,
        name: str,
        utility_spec: UtilitySpec,
        obs_dim: int,
        n_actions: int,
        config: DeepAgentConfig | None = None,
        seed: int = 0,
    ):
        self.name = name
        self.utility_spec = utility_spec
        self.n_actions = n_actions
        self.obs_dim = obs_dim
        self.config = config or DeepAgentConfig()
        self.device = resolve_torch_device(self.config.device)
        configure_torch_runtime(self.device, self.config.torch_num_threads)
        self.use_amp = bool(self.config.use_amp and self.device.type == "cuda")
        self.online_net = MLPQNetwork(obs_dim, n_actions, self.config.hidden_sizes).to(self.device)
        self.target_net = MLPQNetwork(obs_dim, n_actions, self.config.hidden_sizes).to(self.device)
        if self.config.compile_model and hasattr(torch, "compile"):
            try:
                self.online_net = torch.compile(self.online_net)
                self.target_net = torch.compile(self.target_net)
            except Exception:
                pass
        self.target_net.load_state_dict(self.online_net.state_dict())
        self.optimizer = torch.optim.Adam(self.online_net.parameters(), lr=self.config.learning_rate, fused=(self.device.type == "cuda"))
        self.scaler = torch.amp.GradScaler("cuda", enabled=self.use_amp) if self.device.type == "cuda" else None
        self.replay = ReplayBuffer(self.config.replay_size, seed=seed)
        self.rng = np.random.default_rng(seed)
        self.total_steps = 0
        self.last_loss: float | None = None
        self._eval_obs_cpu = torch.empty(
            (1, obs_dim),
            dtype=torch.float32,
            pin_memory=(self.device.type == "cuda"),
        )
        self._eval_obs_device = torch.empty(
            (1, obs_dim),
            dtype=torch.float32,
            device=self.device,
        )

    def _epsilon(self) -> float:
        frac = min(self.total_steps / max(self.config.epsilon_decay, 1), 1.0)
        return float(self.config.epsilon_start + frac * (self.config.epsilon_end - self.config.epsilon_start))

    def _obs_to_device(self, obs: np.ndarray) -> torch.Tensor:
        obs_np = np.asarray(obs, dtype=np.float32).reshape(1, -1)
        if self.device.type == "cuda":
            np.copyto(self._eval_obs_cpu.numpy(), obs_np)
            self._eval_obs_device.copy_(self._eval_obs_cpu, non_blocking=True)
            return self._eval_obs_device
        self._eval_obs_device.copy_(torch.from_numpy(obs_np))
        return self._eval_obs_device

    def act(self, obs: np.ndarray, greedy: bool = False) -> int:
        eps = 0.0 if greedy else self._epsilon()
        if self.rng.random() < eps:
            return int(self.rng.integers(self.n_actions))
        with torch.inference_mode():
            obs_t = self._obs_to_device(obs)
            with torch.autocast(device_type=self.device.type, enabled=self.use_amp):
                q = self.online_net(obs_t)
            return int(torch.argmax(q, dim=1).item())

    def act_many(self, obs_batch: np.ndarray, greedy: bool = False) -> np.ndarray:
        obs_np = np.asarray(obs_batch, dtype=np.float32)
        if obs_np.ndim == 1:
            obs_np = obs_np.reshape(1, -1)
        eps = 0.0 if greedy else self._epsilon()
        random_mask = self.rng.random(obs_np.shape[0]) < eps
        with torch.inference_mode():
            if self.device.type == "cuda":
                obs_cpu = torch.from_numpy(obs_np).pin_memory()
                obs_t = obs_cpu.to(device=self.device, non_blocking=True)
            else:
                obs_t = torch.from_numpy(obs_np).to(self.device)
            with torch.autocast(device_type=self.device.type, enabled=self.use_amp):
                q = self.online_net(obs_t)
            actions = torch.argmax(q, dim=1).detach().cpu().numpy().astype(np.int64, copy=False)
        if np.any(random_mask):
            actions = actions.copy()
            actions[random_mask] = self.rng.integers(self.n_actions, size=int(random_mask.sum()))
        return actions

    def utility_reward(self, raw_rewards: Dict[str, float], info: Dict[str, float] | None = None) -> float:
        own = raw_rewards[self.name]
        others = [reward for agent, reward in raw_rewards.items() if agent != self.name]
        params = dict(self.utility_spec.params)
        if self.utility_spec.family in {"compositional", "symbolic_compositional"}:
            params["context"] = info or {}
        return UtilityModel.utility(self.utility_spec.family, own, others, params)

    def add_experience(self, obs: np.ndarray, action: int, utility_reward: float, next_obs: np.ndarray, done: bool):
        self.replay.add(obs, action, utility_reward, next_obs, done)

    def train_step(self):
        self.total_steps += 1
        if len(self.replay) < max(self.config.warmup_steps, self.config.batch_size):
            return
        if self.total_steps % self.config.train_interval != 0:
            return

        obs_t, act_t, rew_t, next_obs_t, done_t = self.replay.sample_tensors(self.config.batch_size, self.device)

        with torch.autocast(device_type=self.device.type, enabled=self.use_amp):
            q_values = self.online_net(obs_t).gather(1, act_t).squeeze(1)
            with torch.no_grad():
                next_actions = torch.argmax(self.online_net(next_obs_t), dim=1, keepdim=True)
                next_q = self.target_net(next_obs_t).gather(1, next_actions).squeeze(1)
                targets = rew_t + self.config.gamma * (1.0 - done_t) * next_q
            loss = F.smooth_l1_loss(q_values, targets)
        self.optimizer.zero_grad(set_to_none=True)
        if self.scaler is not None:
            self.scaler.scale(loss).backward()
            self.scaler.unscale_(self.optimizer)
            nn.utils.clip_grad_norm_(self.online_net.parameters(), self.config.gradient_clip)
            self.scaler.step(self.optimizer)
            self.scaler.update()
        else:
            loss.backward()
            nn.utils.clip_grad_norm_(self.online_net.parameters(), self.config.gradient_clip)
            self.optimizer.step()
        self.last_loss = float(loss.item())

        if self.total_steps % self.config.target_update_interval == 0:
            self.target_net.load_state_dict(self.online_net.state_dict())

    def update(self, obs: np.ndarray, action: int, utility_reward: float, next_obs: np.ndarray, done: bool):
        self.add_experience(obs, action, utility_reward, next_obs, done)
        self.train_step()


AgentType = QLearningAgent | DeepQAgent


def build_population(
    agent_names: List[str],
    utility_specs: List[UtilitySpec],
    action_sizes: Dict[str, int],
    obs_sizes: Dict[str, int] | None = None,
    obs_highs: Dict[str, np.ndarray] | None = None,
    agent_kind: str = "tabular",
    seed: int = 0,
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
) -> Dict[str, AgentType]:
    if len(agent_names) != len(utility_specs):
        raise ValueError("agent_names and utility_specs must have the same length")
    agents: Dict[str, AgentType] = {}
    for idx, (name, spec) in enumerate(zip(agent_names, utility_specs)):
        if agent_kind == "tabular":
            agents[name] = QLearningAgent(
                name=name,
                utility_spec=spec,
                n_actions=action_sizes[name],
                config=tabular_config,
                seed=seed + idx,
                obs_high=None if obs_highs is None else obs_highs.get(name),
            )
        elif agent_kind == "deep":
            if obs_sizes is None:
                raise ValueError("obs_sizes is required when agent_kind='deep'")
            agents[name] = DeepQAgent(
                name=name,
                utility_spec=spec,
                obs_dim=obs_sizes[name],
                n_actions=action_sizes[name],
                config=deep_config,
                seed=seed + idx,
            )
        else:
            raise ValueError("agent_kind must be 'tabular' or 'deep'")
    return agents


def utility_grid() -> List[UtilitySpec]:
    specs: List[UtilitySpec] = [UtilitySpec("selfish", {"selfish_weight": 1.0})]
    specs.extend(UtilitySpec("altruism", {"gamma": float(g)}) for g in [0.1, 0.3, 0.5, 0.8])
    specs.extend(
        UtilitySpec("fehr_schmidt", {"alpha": float(a), "beta": float(b)})
        for a in [0.4, 0.8, 1.2]
        for b in [0.1, 0.3, 0.5]
    )
    specs.extend(
        UtilitySpec(
            "compositional",
            {"weights": {"own_payoff": 1.0, "others_mean": float(g), "disadv_ineq": -float(a), "adv_ineq": -float(b)}},
        )
        for g in [0.0, 0.2, 0.4]
        for a in [0.0, 0.6]
        for b in [0.0, 0.2]
    )
    return specs
