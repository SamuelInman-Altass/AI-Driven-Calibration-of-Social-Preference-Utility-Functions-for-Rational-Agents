from __future__ import annotations
import warnings

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
from gymnasium import spaces
from pettingzoo import ParallelEnv


@dataclass
class StepRecord:
    env_name: str
    episode: int
    t: int
    agent: str
    action: int
    reward: float
    info: Dict[str, float]


class RepeatedPrisonersDilemmaEnv(ParallelEnv):
    metadata = {"name": "repeated_prisoners_dilemma_v1", "render_modes": ["human"]}

    def __init__(self, horizon: int = 10, benefit: float = 3.0, cost: float = 1.0, seed: Optional[int] = None):
        self.horizon = horizon
        self.benefit = benefit
        self.cost = cost
        self.possible_agents = ["agent_0", "agent_1"]
        self.agents = self.possible_agents[:]
        self._rng = np.random.default_rng(seed)
        self._t = 0
        self._last_actions = {a: 0 for a in self.possible_agents}
        self._coop_counts = {a: 0 for a in self.possible_agents}
        self._defect_streak = {a: 0 for a in self.possible_agents}

    def observation_space(self, agent: str):
        return spaces.Box(low=0, high=1, shape=(6,), dtype=np.float32)

    def action_space(self, agent: str):
        return spaces.Discrete(2)

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None):
        if seed is not None:
            self._rng = np.random.default_rng(seed)
        self.agents = self.possible_agents[:]
        self._t = 0
        self._last_actions = {a: 0 for a in self.possible_agents}
        self._coop_counts = {a: 0 for a in self.possible_agents}
        self._defect_streak = {a: 0 for a in self.possible_agents}
        obs = self._get_obs()
        infos = {a: {} for a in self.agents}
        return obs, infos

    def _get_obs(self):
        obs = {}
        denom = max(self.horizon - 1, 1)
        for agent in self.agents:
            other = self.possible_agents[1] if agent == self.possible_agents[0] else self.possible_agents[0]
            obs[agent] = np.array(
                [
                    self._t / denom,
                    self._last_actions[agent],
                    self._last_actions[other],
                    self._coop_counts[agent] / max(self._t, 1),
                    self._coop_counts[other] / max(self._t, 1),
                    min(self._defect_streak[other], self.horizon) / self.horizon,
                ],
                dtype=np.float32,
            )
        return obs

    def step(self, actions: Dict[str, int]):
        agent0, agent1 = self.possible_agents[0], self.possible_agents[1]
        a0 = int(actions[agent0])
        a1 = int(actions[agent1])
        coop0, coop1 = a0 == 1, a1 == 1
        rewards = {
            agent0: self.benefit * coop1 - self.cost * coop0,
            agent1: self.benefit * coop0 - self.cost * coop1,
        }
        infos = {
            agent0: {"cooperated": float(coop0), "other_cooperated": float(coop1)},
            agent1: {"cooperated": float(coop1), "other_cooperated": float(coop0)},
        }
        self._last_actions = {agent0: a0, agent1: a1}
        self._coop_counts[agent0] += int(coop0)
        self._coop_counts[agent1] += int(coop1)
        self._defect_streak[agent0] = 0 if coop0 else self._defect_streak[agent0] + 1
        self._defect_streak[agent1] = 0 if coop1 else self._defect_streak[agent1] + 1
        self._t += 1
        terminated = self._t >= self.horizon
        terminations = {a: terminated for a in self.agents}
        truncations = {a: False for a in self.agents}
        obs = self._get_obs() if not terminated else {a: np.zeros(6, dtype=np.float32) for a in self.agents}
        if terminated:
            self.agents = []
        return obs, rewards, terminations, truncations, infos

    def render(self):
        print(f"t={self._t}, last_actions={self._last_actions}, coop_counts={self._coop_counts}")


class UltimatumEnv(ParallelEnv):
    metadata = {"name": "ultimatum_repeated_v2", "render_modes": ["human"]}
    _migration_warned = False

    def __init__(self, pie_size: float = 1.0, offer_levels: int = 11, rounds: int = 8, seed: Optional[int] = None):
        self.pie_size = pie_size
        self.offer_levels = offer_levels
        self.rounds = rounds
        self.possible_agents = ["proposer", "responder"]
        self.agents = self.possible_agents[:]
        self._rng = np.random.default_rng(seed)
        self._round = 0
        self._last_offer_frac = 0.0
        self._last_accepted = 0.0
        self._accepted_count = 0
        if not UltimatumEnv._migration_warned:
            warnings.warn("UltimatumEnv observation layout changed in ultimatum_repeated_v2 (shape 5 -> 4). Saved models or results from older versions are not directly compatible and should be rerun.", RuntimeWarning, stacklevel=2)
            UltimatumEnv._migration_warned = True

    def observation_space(self, agent: str):
        return spaces.Box(low=0.0, high=1.0, shape=(4,), dtype=np.float32)

    def action_space(self, agent: str):
        if agent == "proposer":
            return spaces.Discrete(self.offer_levels)
        return spaces.Discrete(2)

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None):
        if seed is not None:
            self._rng = np.random.default_rng(seed)
        self.agents = self.possible_agents[:]
        self._round = 0
        self._last_offer_frac = 0.0
        self._last_accepted = 0.0
        self._accepted_count = 0
        obs = self._get_obs()
        infos = {a: {} for a in self.agents}
        return obs, infos

    def _get_obs(self):
        round_frac = self._round / max(self.rounds - 1, 1)
        accept_rate = self._accepted_count / max(self._round, 1)
        proposer_obs = np.array([round_frac, self._last_offer_frac, self._last_accepted, accept_rate], dtype=np.float32)
        responder_obs = np.array([round_frac, self._last_offer_frac, 1.0 - self._last_offer_frac, accept_rate], dtype=np.float32)
        return {"proposer": proposer_obs, "responder": responder_obs}

    def step(self, actions: Dict[str, int]):
        if set(actions) != set(self.possible_agents):
            missing = sorted(set(self.possible_agents) - set(actions))
            extra = sorted(set(actions) - set(self.possible_agents))
            raise ValueError(f"UltimatumEnv.step expects simultaneous proposer/responder actions; missing={missing}, extra={extra}")
        offer_idx = int(actions["proposer"])
        accept = int(actions["responder"])
        offer_frac = offer_idx / max(self.offer_levels - 1, 1)
        if accept == 1:
            rewards = {"proposer": self.pie_size * (1.0 - offer_frac), "responder": self.pie_size * offer_frac}
            self._accepted_count += 1
        else:
            rewards = {"proposer": 0.0, "responder": 0.0}
        self._last_offer_frac = offer_frac
        self._last_accepted = float(accept)
        infos = {
            "proposer": {"offer_frac": offer_frac, "accepted": float(accept), "round": float(self._round)},
            "responder": {"offer_frac": offer_frac, "accepted": float(accept), "round": float(self._round)},
        }
        self._round += 1
        terminated = self._round >= self.rounds
        if terminated:
            obs = {a: np.zeros(4, dtype=np.float32) for a in self.possible_agents}
            self.agents = []
        else:
            obs = self._get_obs()
        terminations = {a: terminated for a in self.possible_agents}
        truncations = {a: False for a in self.possible_agents}
        return obs, rewards, terminations, truncations, infos

    def render(self):
        print(f"round={self._round}, last_offer={self._last_offer_frac:.2f}, last_accepted={self._last_accepted}")


class PublicGoodsEnv(ParallelEnv):
    metadata = {"name": "public_goods_v1", "render_modes": ["human"]}

    def __init__(
        self,
        n_agents: int = 4,
        horizon: int = 8,
        endowment: float = 1.0,
        contribution_levels: int = 6,
        multiplier: float = 1.6,
        seed: Optional[int] = None,
    ):
        assert n_agents >= 2
        self.n_agents = n_agents
        self.horizon = horizon
        self.endowment = endowment
        self.contribution_levels = contribution_levels
        self.multiplier = multiplier
        self.possible_agents = [f"agent_{i}" for i in range(n_agents)]
        self.agents = self.possible_agents[:]
        self._rng = np.random.default_rng(seed)
        self._t = 0
        self._last_avg_contrib = 0.0
        self._last_own = {a: 0.0 for a in self.possible_agents}
        self._cum_reward = {a: 0.0 for a in self.possible_agents}

    def observation_space(self, agent: str):
        return spaces.Box(low=0.0, high=2.0, shape=(5,), dtype=np.float32)

    def action_space(self, agent: str):
        return spaces.Discrete(self.contribution_levels)

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None):
        if seed is not None:
            self._rng = np.random.default_rng(seed)
        self.agents = self.possible_agents[:]
        self._t = 0
        self._last_avg_contrib = 0.0
        self._last_own = {a: 0.0 for a in self.possible_agents}
        self._cum_reward = {a: 0.0 for a in self.possible_agents}
        obs = self._get_obs()
        infos = {a: {} for a in self.agents}
        return obs, infos

    def _get_obs(self):
        denom = max(self.horizon - 1, 1)
        max_possible_per_round = max(self.multiplier * self.endowment, 1e-6)
        return {
            a: np.array(
                [
                    self._t / denom,
                    self._last_own[a],
                    self._last_avg_contrib,
                    self._cum_reward[a] / max((self._t or 1) * max_possible_per_round, 1e-6),
                    (self._last_avg_contrib - self._last_own[a]) * 0.5 + 0.5,
                ],
                dtype=np.float32,
            )
            for a in self.agents
        }

    def step(self, actions: Dict[str, int]):
        contrib_fracs = {a: int(actions[a]) / (self.contribution_levels - 1) for a in self.agents}
        total = sum(contrib_fracs.values()) * self.endowment
        public_return_per_agent = self.multiplier * total / self.n_agents
        rewards = {a: self.endowment * (1.0 - contrib_fracs[a]) + public_return_per_agent for a in self.agents}
        avg_contrib = float(np.mean(list(contrib_fracs.values())))
        infos = {
            a: {
                "contribution_frac": contrib_fracs[a],
                "avg_contribution_frac": avg_contrib,
                "public_return_per_agent": public_return_per_agent,
            }
            for a in self.agents
        }
        self._last_avg_contrib = avg_contrib
        self._last_own = contrib_fracs.copy()
        for a in self.agents:
            self._cum_reward[a] += rewards[a]
        self._t += 1
        terminated = self._t >= self.horizon
        terminations = {a: terminated for a in self.agents}
        truncations = {a: False for a in self.agents}
        obs = self._get_obs() if not terminated else {a: np.zeros(5, dtype=np.float32) for a in self.agents}
        if terminated:
            self.agents = []
        return obs, rewards, terminations, truncations, infos

    def render(self):
        print(f"t={self._t}, avg_contribution={self._last_avg_contrib:.3f}")


ENV_REGISTRY = {
    "rpd": RepeatedPrisonersDilemmaEnv,
    "ultimatum": UltimatumEnv,
    "public_goods": PublicGoodsEnv,
}


def make_env(env_name: str, **kwargs) -> ParallelEnv:
    if env_name not in ENV_REGISTRY:
        raise ValueError(f"Unknown env_name={env_name}. Expected one of {sorted(ENV_REGISTRY)}")
    return ENV_REGISTRY[env_name](**kwargs)



class DictatorGameEnv(ParallelEnv):
    metadata = {"name": "dictator_game_v1", "render_modes": ["human"]}

    def __init__(self, pie_size: float = 1.0, offer_levels: int = 11, rounds: int = 8, seed: Optional[int] = None):
        self.pie_size = pie_size
        self.offer_levels = offer_levels
        self.rounds = rounds
        self.possible_agents = ["proposer", "recipient"]
        self.agents = self.possible_agents[:]
        self._rng = np.random.default_rng(seed)
        self._round = 0
        self._last_offer_frac = 0.0
        self._cum_rewards = {a: 0.0 for a in self.possible_agents}

    def observation_space(self, agent: str):
        return spaces.Box(low=0.0, high=1.0, shape=(4,), dtype=np.float32)

    def action_space(self, agent: str):
        if agent == "proposer":
            return spaces.Discrete(self.offer_levels)
        return spaces.Discrete(1)

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None):
        if seed is not None:
            self._rng = np.random.default_rng(seed)
        self.agents = self.possible_agents[:]
        self._round = 0
        self._last_offer_frac = 0.0
        self._cum_rewards = {a: 0.0 for a in self.possible_agents}
        return self._get_obs(), {a: {} for a in self.agents}

    def _get_obs(self):
        round_frac = self._round / max(self.rounds - 1, 1)
        proposer_obs = np.array([round_frac, self._last_offer_frac, 1.0 - self._last_offer_frac, self._cum_rewards["proposer"] / max(self._round or 1, 1)], dtype=np.float32)
        recipient_obs = np.array([round_frac, self._last_offer_frac, self._last_offer_frac, self._cum_rewards["recipient"] / max(self._round or 1, 1)], dtype=np.float32)
        return {"proposer": proposer_obs, "recipient": recipient_obs}

    def step(self, actions: Dict[str, int]):
        offer_idx = int(actions.get("proposer", 0))
        offer_frac = offer_idx / max(self.offer_levels - 1, 1)
        rewards = {"proposer": self.pie_size * (1.0 - offer_frac), "recipient": self.pie_size * offer_frac}
        for a, r in rewards.items():
            self._cum_rewards[a] += float(r)
        self._last_offer_frac = offer_frac
        infos = {
            "proposer": {"offer_frac": offer_frac, "accepted": 1.0, "round": float(self._round)},
            "recipient": {"offer_frac": offer_frac, "accepted": 1.0, "round": float(self._round)},
        }
        self._round += 1
        terminated = self._round >= self.rounds
        obs = {a: np.zeros(4, dtype=np.float32) for a in self.possible_agents} if terminated else self._get_obs()
        if terminated:
            self.agents = []
        terminations = {a: terminated for a in self.possible_agents}
        truncations = {a: False for a in self.possible_agents}
        return obs, rewards, terminations, truncations, infos


class SequentialTrustGameEnv(ParallelEnv):
    metadata = {"name": "sequential_trust_game_v1", "render_modes": ["human"]}

    def __init__(self, endowment: float = 1.0, multiplier: float = 3.0, send_levels: int = 11, return_levels: int = 11, rounds: int = 8, seed: Optional[int] = None):
        self.endowment = endowment
        self.multiplier = multiplier
        self.send_levels = send_levels
        self.return_levels = return_levels
        self.rounds = rounds
        self.possible_agents = ["investor", "trustee"]
        self.agents = self.possible_agents[:]
        self._rng = np.random.default_rng(seed)
        self._round = 0
        self._last_send = 0.0
        self._last_return = 0.0
        self._cum_rewards = {a: 0.0 for a in self.possible_agents}

    def observation_space(self, agent: str):
        return spaces.Box(low=0.0, high=3.0, shape=(5,), dtype=np.float32)

    def action_space(self, agent: str):
        return spaces.Discrete(self.send_levels if agent == "investor" else self.return_levels)

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None):
        if seed is not None:
            self._rng = np.random.default_rng(seed)
        self.agents = self.possible_agents[:]
        self._round = 0
        self._last_send = 0.0
        self._last_return = 0.0
        self._cum_rewards = {a: 0.0 for a in self.possible_agents}
        return self._get_obs(), {a: {} for a in self.agents}

    def _get_obs(self):
        round_frac = self._round / max(self.rounds - 1, 1)
        max_trust_pool = max(self.endowment * self.multiplier, 1e-6)
        investor_obs = np.array([
            round_frac,
            self._last_send,
            self._last_return,
            self._cum_rewards["investor"] / max((self._round or 1) * max_trust_pool, 1e-6),
            self._cum_rewards["trustee"] / max((self._round or 1) * max_trust_pool, 1e-6),
        ], dtype=np.float32)
        trustee_obs = np.array([
            round_frac,
            self._last_send,
            self._last_return,
            self._cum_rewards["trustee"] / max((self._round or 1) * max_trust_pool, 1e-6),
            self._cum_rewards["investor"] / max((self._round or 1) * max_trust_pool, 1e-6),
        ], dtype=np.float32)
        return {"investor": investor_obs, "trustee": trustee_obs}

    def step(self, actions: Dict[str, int]):
        send_frac = int(actions.get("investor", 0)) / max(self.send_levels - 1, 1)
        return_frac = int(actions.get("trustee", 0)) / max(self.return_levels - 1, 1)
        sent = self.endowment * send_frac
        trust_pool = sent * self.multiplier
        returned = trust_pool * return_frac
        rewards = {
            "investor": self.endowment - sent + returned,
            "trustee": trust_pool - returned,
        }
        for a, r in rewards.items():
            self._cum_rewards[a] += float(r)
        self._last_send = send_frac
        self._last_return = return_frac
        infos = {
            "investor": {"contribution_frac": send_frac, "cooperated": float(send_frac > 0.0), "trust_return_frac": return_frac, "round": float(self._round)},
            "trustee": {"contribution_frac": return_frac, "cooperated": float(return_frac > 0.0), "trust_send_frac": send_frac, "round": float(self._round)},
        }
        self._round += 1
        terminated = self._round >= self.rounds
        obs = {a: np.zeros(5, dtype=np.float32) for a in self.possible_agents} if terminated else self._get_obs()
        if terminated:
            self.agents = []
        terminations = {a: terminated for a in self.possible_agents}
        truncations = {a: False for a in self.possible_agents}
        return obs, rewards, terminations, truncations, infos


def build_repeated_prisoners_dilemma_env(**kwargs) -> ParallelEnv:
    return RepeatedPrisonersDilemmaEnv(**kwargs)


def build_repeated_ultimatum_env(*, rounds: int = 8, **kwargs) -> ParallelEnv:
    if "horizon" in kwargs:
        raise TypeError("build_repeated_ultimatum_env uses the argument name 'rounds', not 'horizon'.")
    return UltimatumEnv(rounds=rounds, **kwargs)


def build_public_goods_env(**kwargs) -> ParallelEnv:
    return PublicGoodsEnv(**kwargs)


def build_dictator_game_env(*, rounds: int = 8, **kwargs) -> ParallelEnv:
    return DictatorGameEnv(rounds=rounds, **kwargs)


def build_sequential_trust_game_env(*, rounds: int = 8, **kwargs) -> ParallelEnv:
    return SequentialTrustGameEnv(rounds=rounds, **kwargs)
