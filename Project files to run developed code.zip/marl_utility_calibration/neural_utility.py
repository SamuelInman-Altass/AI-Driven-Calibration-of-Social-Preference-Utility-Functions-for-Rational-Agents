from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple

import numpy as np

from .utility_expressions import build_expression_library, expression_matrix, sample_feature_dicts


@dataclass(frozen=True)
class NeuralUtilityConfig:
    input_terms: Sequence[str]
    hidden_sizes: Tuple[int, ...] = (16, 16)
    init_scale: float = 0.35


def _layer_shapes(input_dim: int, hidden_sizes: Sequence[int]) -> List[Tuple[int, int]]:
    dims = [int(input_dim)] + [int(h) for h in hidden_sizes] + [1]
    return [(dims[i], dims[i + 1]) for i in range(len(dims) - 1)]


def initialize_neural_params(config: NeuralUtilityConfig, seed: int = 0) -> Dict[str, object]:
    rng = np.random.default_rng(seed)
    input_terms = list(config.input_terms)
    params: Dict[str, object] = {
        "input_terms": input_terms,
        "hidden_sizes": tuple(int(h) for h in config.hidden_sizes),
        "weights": [],
        "biases": [],
    }
    for fan_in, fan_out in _layer_shapes(len(input_terms), config.hidden_sizes):
        scale = config.init_scale / max(1.0, np.sqrt(float(fan_in)))
        w = rng.normal(0.0, scale, size=(fan_in, fan_out)).astype(float)
        b = np.zeros((fan_out,), dtype=float)
        params["weights"].append(w.tolist())
        params["biases"].append(b.tolist())
    return params


def forward_neural_utility(features: Dict[str, float], params: Dict[str, object]) -> float:
    terms = list(params.get("input_terms", []))
    x = np.asarray([float(features.get(t, 0.0)) for t in terms], dtype=float)
    weights = params.get("weights", [])
    biases = params.get("biases", [])
    if not terms or not weights:
        return 0.0
    h = x
    for i, (w_raw, b_raw) in enumerate(zip(weights, biases)):
        w = np.asarray(w_raw, dtype=float)
        b = np.asarray(b_raw, dtype=float)
        h = h @ w + b
        if i < len(weights) - 1:
            h = np.tanh(h)
    val = float(np.asarray(h).reshape(-1)[0])
    return float(np.clip(val, -10.0, 10.0))


def neural_spec(params: Dict[str, object]):
    from .agents import UtilitySpec
    return UtilitySpec("neural_utility", params)


def flatten_neural_params(params: Dict[str, object]) -> np.ndarray:
    flat: List[float] = []
    for w in params.get("weights", []):
        flat.extend(np.asarray(w, dtype=float).ravel().tolist())
    for b in params.get("biases", []):
        flat.extend(np.asarray(b, dtype=float).ravel().tolist())
    return np.asarray(flat, dtype=float)


def unflatten_neural_params(flat: np.ndarray, template: Dict[str, object]) -> Dict[str, object]:
    flat = np.asarray(flat, dtype=float).ravel()
    out = {
        "input_terms": list(template.get("input_terms", [])),
        "hidden_sizes": tuple(template.get("hidden_sizes", ())),
        "weights": [],
        "biases": [],
    }
    idx = 0
    for w in template.get("weights", []):
        arr = np.asarray(w, dtype=float)
        n = int(arr.size)
        out["weights"].append(flat[idx: idx + n].reshape(arr.shape).tolist())
        idx += n
    for b in template.get("biases", []):
        arr = np.asarray(b, dtype=float)
        n = int(arr.size)
        out["biases"].append(flat[idx: idx + n].reshape(arr.shape).tolist())
        idx += n
    return out


def mutate_neural_params(params: Dict[str, object], sigma: float = 0.08, seed: int = 0) -> Dict[str, object]:
    rng = np.random.default_rng(seed)
    flat = flatten_neural_params(params)
    mutated = flat + rng.normal(0.0, sigma, size=flat.shape)
    return unflatten_neural_params(mutated, params)


def crossover_neural_params(a: Dict[str, object], b: Dict[str, object], seed: int = 0) -> Dict[str, object]:
    rng = np.random.default_rng(seed)
    fa = flatten_neural_params(a)
    fb = flatten_neural_params(b)
    mask = rng.random(size=fa.shape) < 0.5
    child = np.where(mask, fa, fb)
    return unflatten_neural_params(child, a)


def fit_sparse_symbolic_to_targets(
    targets: np.ndarray,
    feature_rows: Sequence[Dict[str, float]],
    expression_library: Sequence[str] | None = None,
    beam_width: int = 4,
    max_terms: int = 3,
    complexity_penalty: float = 0.02,
) -> Dict[str, float]:
    expr_library = list(expression_library) if expression_library is not None else build_expression_library(include_ratio=True)
    X_full = expression_matrix(expr_library, feature_rows)
    y = np.asarray(targets, dtype=float).ravel()
    n = len(expr_library)
    if n == 0:
        return {}
    beams: List[Tuple[List[int], float]] = [([], float(np.mean((y - y.mean()) ** 2) + complexity_penalty))]
    best_indices: List[int] = []
    best_score = float('inf')
    for _ in range(int(max_terms)):
        proposals: List[Tuple[List[int], float]] = []
        seen = set()
        for indices, _ in beams:
            remaining = [j for j in range(n) if j not in indices]
            for j in remaining:
                cand = sorted(indices + [j])
                key = tuple(cand)
                if key in seen:
                    continue
                seen.add(key)
                X = X_full[:, cand]
                coef, *_ = np.linalg.lstsq(X, y, rcond=None)
                pred = X @ coef
                mse = float(np.mean((pred - y) ** 2))
                score = mse + complexity_penalty * len(cand)
                proposals.append((cand, score))
                if score < best_score:
                    best_score = score
                    best_indices = cand
        if not proposals:
            break
        proposals.sort(key=lambda x: x[1])
        beams = proposals[: max(1, int(beam_width))]
    if not best_indices:
        return {}
    X = X_full[:, best_indices]
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    weights = {expr_library[j]: float(c) for j, c in zip(best_indices, coef) if abs(float(c)) > 1e-10}
    return weights


def distill_neural_to_symbolic(
    neural_params: Dict[str, object],
    expression_library: Sequence[str] | None = None,
    n_samples: int = 384,
    seed: int = 0,
    beam_width: int = 4,
    max_terms: int = 3,
    complexity_penalty: float = 0.02,
) -> Dict[str, object]:
    feature_rows = sample_feature_dicts(n_samples=n_samples, seed=seed)
    targets = np.asarray([forward_neural_utility(row, neural_params) for row in feature_rows], dtype=float)
    weights = fit_sparse_symbolic_to_targets(
        targets=targets,
        feature_rows=feature_rows,
        expression_library=expression_library,
        beam_width=beam_width,
        max_terms=max_terms,
        complexity_penalty=complexity_penalty,
    )
    X = expression_matrix(list(weights.keys()), feature_rows)
    pred = X @ np.asarray(list(weights.values()), dtype=float) if weights else np.zeros_like(targets)
    mse = float(np.mean((pred - targets) ** 2))
    return {
        "weights": weights,
        "distillation_mse": mse,
        "n_samples": int(n_samples),
    }
