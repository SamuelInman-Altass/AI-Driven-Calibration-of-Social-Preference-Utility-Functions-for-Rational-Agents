from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Sequence

import pandas as pd

from .agents import AgentConfig, DeepAgentConfig, UtilityModel, UtilitySpec
from .calibration import PopulationCandidate, evaluate_candidate
from .tracking import moment_loss


DEFAULT_TERMS: List[str] = [
    "own_payoff",
    "others_mean",
    "disadv_ineq",
    "adv_ineq",
    "accepted",
    "cooperated",
    "contribution_frac",
    "offer_frac",
]


@dataclass(frozen=True)
class SearchConfig:
    terms: Sequence[str] = tuple(DEFAULT_TERMS)
    max_terms: int = 3
    weight_grid: Sequence[float] = (-1.0, -0.5, -0.2, 0.2, 0.5, 1.0)
    complexity_penalty: float = 0.02
    max_candidates: int | None = 20000


@dataclass
class SearchResult:
    candidate: PopulationCandidate
    train_loss: float
    validation_loss: float
    test_loss: float | None
    complexity: int
    score: float
    predicted_train: Dict[str, float]
    predicted_validation: Dict[str, float]
    predicted_test: Dict[str, float] | None = None
    selection_score: float | None = None
    test_score: float | None = None
    selection_basis: str = "validation_loss"


def compositional_spec(weights: Dict[str, float]) -> UtilitySpec:
    sparse = {k: float(v) for k, v in weights.items() if abs(float(v)) > 1e-12}
    return UtilitySpec("compositional", {"weights": sparse})


def generate_compositional_specs(config: SearchConfig) -> List[UtilitySpec]:
    import warnings
    specs: List[UtilitySpec] = []
    seen: set[tuple] = set()
    emitted = 0
    for n_terms in range(1, int(config.max_terms) + 1):
        for terms in itertools.combinations(config.terms, n_terms):
            for vals in itertools.product(config.weight_grid, repeat=n_terms):
                weights = {term: float(val) for term, val in zip(terms, vals) if abs(float(val)) > 1e-12}
                if not weights:
                    continue
                key = tuple(sorted(weights.items()))
                if key in seen:
                    continue
                seen.add(key)
                specs.append(compositional_spec(weights))
                emitted += 1
                if config.max_candidates is not None and emitted >= int(config.max_candidates):
                    warnings.warn(f"generate_compositional_specs truncated search space at max_candidates={config.max_candidates}", RuntimeWarning, stacklevel=2)
                    return specs
    return specs


def fixed_baseline_specs() -> List[UtilitySpec]:
    return [
        UtilitySpec("selfish", {"selfish_weight": 1.0}),
        UtilitySpec("social_tradeoff", {"selfish_weight": 1.0, "altruism_weight": 1.0, "other_payoff_aggregation": "mean"}),
        UtilitySpec("inequity_aversion", {"selfish_weight": 1.0, "alpha": 0.8, "beta": 0.3}),
    ]


def candidate_from_spec(spec: UtilitySpec, n_agents: int, prefix: str = "candidate") -> PopulationCandidate:
    if spec.family == "compositional":
        name = prefix + "_compositional_" + "_".join(f"{k}={v:g}" for k, v in sorted(spec.params.get("weights", {}).items()))
    else:
        name = prefix + "_" + spec.family
    return PopulationCandidate(name=name, utility_specs=[spec for _ in range(n_agents)])


def split_moments(flat_moments: Dict[str, float], train_env_names: Iterable[str], validation_env_names: Iterable[str]):
    train_prefix = {f"{name}::" for name in train_env_names}
    val_prefix = {f"{name}::" for name in validation_env_names}
    train = {k: v for k, v in flat_moments.items() if any(k.startswith(p) for p in train_prefix)}
    val = {k: v for k, v in flat_moments.items() if any(k.startswith(p) for p in val_prefix)}
    return train, val


def candidate_complexity(candidate: PopulationCandidate) -> int:
    if not candidate.utility_specs:
        return 0
    return int(sum(UtilityModel.complexity(spec) for spec in candidate.utility_specs) / len(candidate.utility_specs))


def search_best_utility(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    n_agents: int,
    test_env_builders: Dict[str, Callable[[], object]] | None = None,
    search_config: SearchConfig | None = None,
    include_fixed_baselines: bool = True,
    train_episodes: int = 48,
    seed: int = 0,
    weights: Dict[str, float] | None = None,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
    evaluate_top_k_on_test: int | None = 2,
    greedy_tail_frac: float = 0.2,
) -> List[SearchResult]:
    config = search_config or SearchConfig()
    target_train, target_val = split_moments(target_moments, train_env_builders.keys(), validation_env_builders.keys())
    test_env_builders = test_env_builders or {}
    target_test = {k: v for k, v in target_moments.items() if any(k.startswith(f"{name}::") for name in test_env_builders.keys())}

    candidate_specs = generate_compositional_specs(config)
    if include_fixed_baselines:
        candidate_specs = fixed_baseline_specs() + candidate_specs

    results: List[SearchResult] = []
    for idx, spec in enumerate(candidate_specs):
        candidate = candidate_from_spec(spec, n_agents=n_agents)
        pred_train = evaluate_candidate(
            candidate,
            train_env_builders,
            train_episodes=train_episodes,
            seed=seed + idx * 17,
            agent_kind=agent_kind,
            tabular_config=tabular_config,
            deep_config=deep_config,
            greedy_tail_frac=greedy_tail_frac,
        )
        pred_val = evaluate_candidate(
            candidate,
            validation_env_builders,
            train_episodes=train_episodes,
            seed=seed + idx * 17 + 999,
            agent_kind=agent_kind,
            tabular_config=tabular_config,
            deep_config=deep_config,
            greedy_tail_frac=greedy_tail_frac,
        )
        train_loss = moment_loss(pred_train, target_train, weights=weights)
        validation_loss = moment_loss(pred_val, target_val, weights=weights)
        complexity = candidate_complexity(candidate)
        score = float(validation_loss + config.complexity_penalty * complexity)
        results.append(
            SearchResult(
                candidate=candidate,
                train_loss=float(train_loss),
                validation_loss=float(validation_loss),
                test_loss=None,
                complexity=complexity,
                score=score,
                predicted_train=pred_train,
                predicted_validation=pred_val,
                predicted_test=None,
                selection_score=score,
                test_score=None,
                selection_basis="validation_loss",
            )
        )
    results.sort(key=lambda r: r.score)

    if test_env_builders and evaluate_top_k_on_test and evaluate_top_k_on_test > 0:
        for rank, result in enumerate(results[: int(evaluate_top_k_on_test)]):
            pred_test = evaluate_candidate(
                result.candidate,
                test_env_builders,
                train_episodes=train_episodes,
                seed=seed + 50000 + rank * 131,
                agent_kind=agent_kind,
                tabular_config=tabular_config,
                deep_config=deep_config,
                greedy_tail_frac=greedy_tail_frac,
            )
            result.predicted_test = pred_test
            result.test_loss = float(moment_loss(pred_test, target_test, weights=weights)) if target_test else None
            result.test_score = (result.test_loss + result.complexity * float(config.complexity_penalty)) if result.test_loss is not None else None
    return results


def search_results_to_frame(results: List[SearchResult]) -> pd.DataFrame:
    rows = []
    for r in results:
        row = {
            "candidate": r.candidate.name,
            "train_loss": r.train_loss,
            "validation_loss": r.validation_loss,
            "complexity": r.complexity,
            "score": r.score,
            "selection_score": r.selection_score,
            "selection_basis": r.selection_basis,
            "test_loss": r.test_loss,
            "test_score": r.test_score,
        }
        row.update({f"train::{k}": v for k, v in r.predicted_train.items()})
        row.update({f"val::{k}": v for k, v in r.predicted_validation.items()})
        if r.predicted_test is not None:
            row.update({f"test::{k}": v for k, v in r.predicted_test.items()})
        rows.append(row)
    return pd.DataFrame(rows)
