from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List

import pandas as pd

from .agents import AgentConfig, DeepAgentConfig, UtilitySpec, build_population
from .tracking import (
    flatten_moments,
    load_empirical_targets,
    moment_loss,
    run_training,
    run_training_parallel_envs,
    summarize_logs,
)


@dataclass(frozen=True)
class PopulationCandidate:
    name: str
    utility_specs: List[UtilitySpec]


def evaluate_candidate(
    candidate: PopulationCandidate,
    env_builders: Dict[str, Callable[[], object]],
    train_episodes: int = 250,
    seed: int = 0,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
    verbose: bool = True,
    greedy_tail_frac: float = 0.2,
) -> Dict[str, float]:
    moments_by_env: Dict[str, Dict[str, float]] = {}
    if verbose:
        print(
            f"[evaluate_candidate] candidate={candidate.name} agent_kind={agent_kind} episodes={train_episodes} envs={list(env_builders.keys())}",
            flush=True,
        )

    for env_name, builder in env_builders.items():
        if verbose:
            print(f"  -> env={env_name} starting", flush=True)

        env = builder()
        try:
            action_sizes = {agent: env.action_space(agent).n for agent in env.possible_agents}
            obs_spaces = {agent: env.observation_space(agent) for agent in env.possible_agents}
            obs_sizes = {agent: int(space.shape[0]) for agent, space in obs_spaces.items()}
            obs_highs = {agent: getattr(space, "high", None) for agent, space in obs_spaces.items()}
            needed = len(env.possible_agents)

            if not candidate.utility_specs:
                raise ValueError(f"Candidate '{candidate.name}' has no utility specs for env '{env_name}'.")
            if len(candidate.utility_specs) >= needed:
                specs = candidate.utility_specs[:needed]
            else:
                reps = (needed + len(candidate.utility_specs) - 1) // len(candidate.utility_specs)
                specs = (candidate.utility_specs * reps)[:needed]

            agents = build_population(
                env.possible_agents,
                specs,
                action_sizes,
                obs_sizes=obs_sizes,
                obs_highs=obs_highs,
                agent_kind=agent_kind,
                seed=seed,
                tabular_config=tabular_config,
                deep_config=deep_config,
            )
            parallel_envs = 1
            if agent_kind == "deep" and deep_config is not None:
                parallel_envs = max(int(getattr(deep_config, "parallel_envs", 1)), 1)

            if agent_kind == "deep":
                tail_frac = max(0.0, min(float(greedy_tail_frac), 1.0))
                tail_eps = int(train_episodes * tail_frac)
                if tail_frac > 0.0 and train_episodes > 1:
                    tail_eps = max(1, min(tail_eps, train_episodes - 1))
                elif tail_frac > 0.0 and train_episodes <= 1:
                    raise ValueError(
                        f"greedy_tail_frac={tail_frac} requires train_episodes > 1; got {train_episodes} "
                        f"for env '{env_name}' and candidate '{candidate.name}'."
                    )
                else:
                    tail_eps = 0
                train_eps = int(train_episodes - tail_eps)

                if parallel_envs > 1:
                    if train_eps > 0:
                        run_training_parallel_envs(
                            builder,
                            agents,
                            episodes=train_eps,
                            seed=seed,
                            parallel_envs=parallel_envs,
                            greedy_eval=False,
                        )
                    if tail_eps > 0:
                        df = run_training_parallel_envs(
                            builder,
                            agents,
                            episodes=tail_eps,
                            seed=seed + train_eps,
                            parallel_envs=parallel_envs,
                            greedy_eval=True,
                        )
                    else:
                        df = pd.DataFrame()
                else:
                    if train_eps > 0:
                        run_training(
                            builder(),
                            agents,
                            episodes=train_eps,
                            seed=seed,
                            greedy_eval=False,
                        )
                    if tail_eps > 0:
                        df = run_training(
                            builder(),
                            agents,
                            episodes=tail_eps,
                            seed=seed + train_eps,
                            greedy_eval=True,
                        )
                    else:
                        df = pd.DataFrame()

                if tail_frac > 0.0:
                    if tail_eps <= 0:
                        raise ValueError(
                            f"Greedy tail rounded to zero episodes for env '{env_name}' and candidate '{candidate.name}'. "
                            "Increase train_episodes or greedy_tail_frac, or set greedy_tail_frac=0."
                        )
                    if df.empty:
                        raise ValueError(
                            f"Greedy tail produced no logged rows for env '{env_name}' and candidate '{candidate.name}'. "
                            "Refusing to score an empty tail because it would create all-NaN moments and corrupt evaluation."
                        )
            else:
                if parallel_envs > 1:
                    df = run_training_parallel_envs(
                        builder,
                        agents,
                        episodes=train_episodes,
                        seed=seed,
                        parallel_envs=parallel_envs,
                    )
                else:
                    df = run_training(env, agents, episodes=train_episodes, seed=seed)

            if df.empty:
                raise ValueError(
                    f"No logged rows were produced for env '{env_name}' and candidate '{candidate.name}'. "
                    "Refusing to score an empty trajectory because it would create all-NaN moments and corrupt evaluation."
                )
            moments_by_env[env_name] = summarize_logs(df)
            if verbose:
                print(f"  <- env={env_name} done rows={len(df)} moments={len(moments_by_env[env_name])}", flush=True)
        finally:
            close_fn = getattr(env, "close", None)
            if callable(close_fn):
                close_fn()

    return flatten_moments(moments_by_env)


def calibrate_population_mix(
    target_moments: Dict[str, float],
    candidates: List[PopulationCandidate],
    env_builders: Dict[str, Callable[[], object]],
    train_episodes: int = 250,
    seed: int = 0,
    weights: Dict[str, float] | None = None,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
):
    results = []
    for idx, candidate in enumerate(candidates):
        pred = evaluate_candidate(
            candidate,
            env_builders,
            train_episodes=train_episodes,
            seed=seed + 100 * idx,
            agent_kind=agent_kind,
            tabular_config=tabular_config,
            deep_config=deep_config,
        )
        loss = moment_loss(pred, target_moments, weights=weights)
        results.append({"candidate": candidate, "predicted": pred, "loss": loss})
    results.sort(key=lambda x: x["loss"])
    return results


def calibrate_population_to_csv(
    csv_path: str | Path,
    candidates: List[PopulationCandidate],
    env_builders: Dict[str, Callable[[], object]],
    train_episodes: int = 250,
    seed: int = 0,
    weights: Dict[str, float] | None = None,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
) -> tuple[Dict[str, float], pd.DataFrame]:
    target_moments = load_empirical_targets(csv_path)
    ranked = calibrate_population_mix(
        target_moments,
        candidates,
        env_builders,
        train_episodes=train_episodes,
        seed=seed,
        weights=weights,
        agent_kind=agent_kind,
        tabular_config=tabular_config,
        deep_config=deep_config,
    )
    rows = []
    for item in ranked:
        row = {"candidate": item["candidate"].name, "loss": item["loss"]}
        row.update(item["predicted"])
        rows.append(row)
    return target_moments, pd.DataFrame(rows)
