from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Sequence

import numpy as np
import pandas as pd

from .agents import AgentConfig, DeepAgentConfig, UtilityModel, UtilitySpec
from .calibration import PopulationCandidate, evaluate_candidate
from .neural_utility import (
    NeuralUtilityConfig,
    crossover_neural_params,
    distill_neural_to_symbolic,
    initialize_neural_params,
    mutate_neural_params,
    neural_spec,
)
from .tracking import moment_loss
from .utility_expressions import BASE_FEATURES, active_expression_count, build_expression_library
from .utility_search import SearchResult


@dataclass(frozen=True)
class BeamSearchConfig:
    base_features: Sequence[str] = BASE_FEATURES
    beam_width: int = 1
    max_terms: int = 2
    weight_grid: Sequence[float] = (-1.0, -0.25, 0.25, 0.35, 1.0)
    complexity_penalty: float = 0.03
    max_library_size: int = 10
    include_ratio: bool = True


@dataclass(frozen=True)
class EvolutionarySearchConfig:
    base_features: Sequence[str] = BASE_FEATURES
    population_size: int = 8
    generations: int = 2
    max_terms: int = 2
    mutation_prob: float = 0.35
    mutation_scale: float = 0.25
    complexity_penalty: float = 0.03
    max_library_size: int = 12
    include_ratio: bool = True


@dataclass(frozen=True)
class NeuralOuterLoopConfig:
    input_terms: Sequence[str] = BASE_FEATURES
    hidden_sizes: tuple[int, ...] = (16, 16)
    population_size: int = 8
    generations: int = 2
    mutation_sigma: float = 0.10
    complexity_penalty: float = 0.001


@dataclass
class IntegratedSearchOutput:
    ranking: pd.DataFrame
    best_result: SearchResult
    distillation: Dict[str, object]
    beam_ranking: pd.DataFrame
    evolutionary_ranking: pd.DataFrame
    neural_ranking: pd.DataFrame


@dataclass(frozen=True)
class EvaluationContext:
    target_train: Dict[str, float]
    target_val: Dict[str, float]
    target_test: Dict[str, float]
    train_env_builders: Dict[str, Callable[[], object]]
    validation_env_builders: Dict[str, Callable[[], object]]
    test_env_builders: Dict[str, Callable[[], object]] | None
    n_agents: int
    train_episodes: int
    weights: Dict[str, float] | None
    agent_kind: str
    tabular_config: AgentConfig | None
    deep_config: DeepAgentConfig | None
    complexity_penalty: float
    greedy_tail_frac: float = 0.2


INVALID_EMPTY_SYMBOLIC_PENALTY = 1.0


def _canonical_symbolic_seed_weights() -> List[Dict[str, float]]:
    return [
        {"own_payoff": 1.0},
        {"others_mean": 1.0},
        {"own_payoff": 1.0, "others_mean": 1.0},
    ]


def _split_targets(target_moments: Dict[str, float], train_envs, validation_envs, test_envs=None):
    train = {k: v for k, v in target_moments.items() if any(k.startswith(f"{name}::") for name in train_envs.keys())}
    val = {k: v for k, v in target_moments.items() if any(k.startswith(f"{name}::") for name in validation_envs.keys())}
    test_envs = test_envs or {}
    test = {k: v for k, v in target_moments.items() if any(k.startswith(f"{name}::") for name in test_envs.keys())}
    return train, val, test


def _candidate_from_spec(spec: UtilitySpec, n_agents: int, prefix: str) -> PopulationCandidate:
    if spec.family in {"compositional", "symbolic_compositional"}:
        weights = spec.params.get("weights", {})
        suffix = "_".join(f"{k}={v:.3g}" for k, v in sorted(weights.items()))
        name = f"{prefix}_{spec.family}_{suffix}" if suffix else f"{prefix}_{spec.family}"
    else:
        name = f"{prefix}_{spec.family}"
    return PopulationCandidate(name=name, utility_specs=[spec for _ in range(n_agents)])


def _evaluate_spec(spec: UtilitySpec, ctx: EvaluationContext, seed: int, prefix: str) -> SearchResult:
    cand = _candidate_from_spec(spec, n_agents=ctx.n_agents, prefix=prefix)
    is_empty_symbolic = spec.family in {"compositional", "symbolic_compositional"} and active_expression_count(spec.params.get("weights", {})) == 0
    pred_train = evaluate_candidate(cand, ctx.train_env_builders, train_episodes=ctx.train_episodes, seed=seed, agent_kind=ctx.agent_kind, tabular_config=ctx.tabular_config, deep_config=ctx.deep_config, greedy_tail_frac=ctx.greedy_tail_frac)
    pred_val = evaluate_candidate(cand, ctx.validation_env_builders, train_episodes=ctx.train_episodes, seed=seed + 100_000, agent_kind=ctx.agent_kind, tabular_config=ctx.tabular_config, deep_config=ctx.deep_config, greedy_tail_frac=ctx.greedy_tail_frac)
    pred_test = None
    test_loss = None
    if ctx.test_env_builders:
        pred_test = evaluate_candidate(cand, ctx.test_env_builders, train_episodes=ctx.train_episodes, seed=seed + 200_000, agent_kind=ctx.agent_kind, tabular_config=ctx.tabular_config, deep_config=ctx.deep_config, greedy_tail_frac=ctx.greedy_tail_frac)
        test_loss = moment_loss(pred_test, ctx.target_test, weights=ctx.weights) if ctx.target_test else None
    complexity = UtilityModel.complexity(spec)
    train_loss = moment_loss(pred_train, ctx.target_train, weights=ctx.weights)
    val_loss = moment_loss(pred_val, ctx.target_val, weights=ctx.weights)
    if is_empty_symbolic:
        complexity = max(complexity, 1)
        train_loss = float(train_loss + INVALID_EMPTY_SYMBOLIC_PENALTY)
        val_loss = float(val_loss + INVALID_EMPTY_SYMBOLIC_PENALTY)
        if test_loss is not None:
            test_loss = float(test_loss + INVALID_EMPTY_SYMBOLIC_PENALTY)
    score = float(val_loss + ctx.complexity_penalty * complexity)
    return SearchResult(cand, train_loss, val_loss, test_loss, complexity, score, pred_train, pred_val, pred_test)


def _to_frame(results: List[SearchResult]) -> pd.DataFrame:
    rows = []
    for r in results:
        rows.append({
            "candidate": r.candidate.name,
            "train_loss": r.train_loss,
            "validation_loss": r.validation_loss,
            "test_loss": np.nan if r.test_loss is None else r.test_loss,
            "complexity": r.complexity,
            "score": r.score,
            "family": r.candidate.utility_specs[0].family if r.candidate.utility_specs else "",
        })
    return pd.DataFrame(rows).sort_values(["score", "validation_loss", "train_loss"]).reset_index(drop=True)


def beam_symbolic_search(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    n_agents: int,
    config: BeamSearchConfig,
    train_episodes: int,
    seed: int,
    weights: Dict[str, float] | None,
    agent_kind: str,
    tabular_config: AgentConfig | None,
    deep_config: DeepAgentConfig | None,
    greedy_tail_frac: float = 0.2,
) -> List[SearchResult]:
    target_train, target_val, target_test = _split_targets(target_moments, train_env_builders, validation_env_builders, test_env_builders)
    ctx = EvaluationContext(target_train, target_val, target_test, train_env_builders, validation_env_builders, test_env_builders, n_agents, train_episodes, weights, agent_kind, tabular_config, deep_config, config.complexity_penalty, greedy_tail_frac)
    library = build_expression_library(config.base_features, include_ratio=config.include_ratio)[: int(config.max_library_size)]
    beam: List[tuple[Dict[str, float], float]] = [({}, 0.0)]
    finals: List[SearchResult] = []
    seed_specs = [UtilitySpec("symbolic_compositional", {"weights": w}) for w in _canonical_symbolic_seed_weights()]
    finals.extend([_evaluate_spec(spec, ctx, seed + 5000 + i, prefix="beam") for i, spec in enumerate(seed_specs)])
    for depth in range(1, int(config.max_terms) + 1):
        proposals: List[SearchResult] = []
        seen = set()
        candidate_counter = 0
        for weights_so_far, _ in beam:
            remaining = [expr for expr in library if expr not in weights_so_far]
            for expr in remaining:
                for val in config.weight_grid:
                    cand_weights = dict(weights_so_far)
                    cand_weights[expr] = float(val)
                    key = tuple(sorted(cand_weights.items()))
                    if key in seen:
                        continue
                    seen.add(key)
                    spec = UtilitySpec("symbolic_compositional", {"weights": cand_weights})
                    res = _evaluate_spec(spec, ctx, seed + depth * 10000 + candidate_counter, prefix="beam")
                    proposals.append(res)
                    candidate_counter += 1
        proposals.sort(key=lambda r: r.score)
        finals.extend(proposals[: config.beam_width])
        beam = [(dict(r.candidate.utility_specs[0].params.get("weights", {})), r.score) for r in proposals[: config.beam_width]]
    finals.sort(key=lambda r: r.score)
    dedup: List[SearchResult] = []
    seen = set()
    for r in finals:
        key = tuple(sorted(r.candidate.utility_specs[0].params.get("weights", {}).items()))
        if key in seen:
            continue
        seen.add(key)
        dedup.append(r)
    return dedup


def _mutate_symbolic(weights: Dict[str, float], library: Sequence[str], cfg: EvolutionarySearchConfig, rng: np.random.Generator) -> Dict[str, float]:
    out = dict(weights)
    if (not out) or rng.random() < cfg.mutation_prob:
        expr = str(rng.choice(library))
        out[expr] = float(rng.normal(0.0, cfg.mutation_scale))
    keys = list(out.keys())
    for key in keys:
        if rng.random() < cfg.mutation_prob:
            out[key] = float(out[key] + rng.normal(0.0, cfg.mutation_scale))
        if rng.random() < 0.10:
            out.pop(key, None)
    if len(out) > cfg.max_terms:
        keep = sorted(out.items(), key=lambda kv: abs(kv[1]), reverse=True)[: cfg.max_terms]
        out = dict(keep)
    out = {k: float(v) for k, v in out.items() if abs(float(v)) > 1e-8}
    if not out:
        expr = str(rng.choice(library))
        weight = float(rng.normal(0.0, cfg.mutation_scale))
        if abs(weight) <= 1e-8:
            weight = float(cfg.mutation_scale if cfg.mutation_scale > 0 else 0.25)
        out = {expr: weight}
    return out


def evolutionary_symbolic_search(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    n_agents: int,
    config: EvolutionarySearchConfig,
    train_episodes: int,
    seed: int,
    weights: Dict[str, float] | None,
    agent_kind: str,
    tabular_config: AgentConfig | None,
    deep_config: DeepAgentConfig | None,
    greedy_tail_frac: float = 0.2,
) -> List[SearchResult]:
    target_train, target_val, target_test = _split_targets(target_moments, train_env_builders, validation_env_builders, test_env_builders)
    ctx = EvaluationContext(target_train, target_val, target_test, train_env_builders, validation_env_builders, test_env_builders, n_agents, train_episodes, weights, agent_kind, tabular_config, deep_config, config.complexity_penalty, greedy_tail_frac)
    library = build_expression_library(config.base_features, include_ratio=config.include_ratio)[: int(config.max_library_size)]
    rng = np.random.default_rng(seed)
    population: List[Dict[str, float]] = [dict(w) for w in _canonical_symbolic_seed_weights()[: config.population_size]]
    while len(population) < config.population_size:
        weights0: Dict[str, float] = {}
        n_terms = int(rng.integers(1, config.max_terms + 1))
        exprs = rng.choice(library, size=n_terms, replace=False)
        for expr in exprs:
            weights0[str(expr)] = float(rng.normal(0.0, config.mutation_scale))
        population.append(weights0)
    archive: List[SearchResult] = []
    for gen in range(config.generations):
        scored: List[SearchResult] = []
        for i, cand_weights in enumerate(population):
            spec = UtilitySpec("symbolic_compositional", {"weights": cand_weights})
            res = _evaluate_spec(spec, ctx, seed + gen * 1000 + i, prefix="evo")
            scored.append(res)
        scored.sort(key=lambda r: r.score)
        elite_count = min(config.population_size, max(2, config.population_size // 3))
        archive.extend(scored[: elite_count])
        elites = scored[: elite_count]
        elite_weights = [dict(r.candidate.utility_specs[0].params.get("weights", {})) for r in elites]
        new_pop = elite_weights.copy()
        while len(new_pop) < config.population_size:
            parent = elite_weights[int(rng.integers(len(elite_weights)))] if elite_weights else {}
            child = _mutate_symbolic(parent, library, config, rng)
            new_pop.append(child)
        population = new_pop
    archive.sort(key=lambda r: r.score)
    dedup: List[SearchResult] = []
    seen = set()
    for r in archive:
        key = tuple(sorted(r.candidate.utility_specs[0].params.get("weights", {}).items()))
        if key in seen:
            continue
        seen.add(key)
        dedup.append(r)
    return dedup


def neural_utility_search(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    n_agents: int,
    config: NeuralOuterLoopConfig,
    train_episodes: int,
    seed: int,
    weights: Dict[str, float] | None,
    agent_kind: str,
    tabular_config: AgentConfig | None,
    deep_config: DeepAgentConfig | None,
    greedy_tail_frac: float = 0.2,
) -> List[SearchResult]:
    target_train, target_val, target_test = _split_targets(target_moments, train_env_builders, validation_env_builders, test_env_builders)
    pop = [initialize_neural_params(NeuralUtilityConfig(input_terms=config.input_terms, hidden_sizes=config.hidden_sizes), seed=seed + i) for i in range(config.population_size)]
    archive: List[SearchResult] = []
    rng = np.random.default_rng(seed)
    for gen in range(config.generations):
        scored: List[SearchResult] = []
        for i, params in enumerate(pop):
            spec = neural_spec(params)
            ctx = EvaluationContext(target_train, target_val, target_test, train_env_builders, validation_env_builders, test_env_builders, n_agents, train_episodes, weights, agent_kind, tabular_config, deep_config, config.complexity_penalty, greedy_tail_frac)
            res = _evaluate_spec(spec, ctx, seed + gen * 1000 + i, prefix="neural")
            scored.append(res)
        scored.sort(key=lambda r: r.score)
        archive.extend(scored[: max(2, config.population_size // 3)])
        elites = [r.candidate.utility_specs[0].params for r in scored[: max(2, config.population_size // 3)]]
        new_pop = list(elites)
        while len(new_pop) < config.population_size:
            if len(elites) >= 2 and rng.random() < 0.5:
                a = elites[int(rng.integers(len(elites)))]
                b = elites[int(rng.integers(len(elites)))]
                child = crossover_neural_params(a, b, seed=int(rng.integers(10_000_000)))
            else:
                a = elites[int(rng.integers(len(elites)))]
                child = dict(a)
            child = mutate_neural_params(child, sigma=config.mutation_sigma, seed=int(rng.integers(10_000_000)))
            new_pop.append(child)
        pop = new_pop
    archive.sort(key=lambda r: r.score)
    return archive


def run_integrated_search(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    n_agents: int,
    train_episodes: int = 36,
    seed: int = 0,
    weights: Dict[str, float] | None = None,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
    beam_config: BeamSearchConfig | None = None,
    evo_config: EvolutionarySearchConfig | None = None,
    neural_config: NeuralOuterLoopConfig | None = None,
    greedy_tail_frac: float = 0.2,
) -> IntegratedSearchOutput:
    beam_config = beam_config or BeamSearchConfig()
    evo_config = evo_config or EvolutionarySearchConfig()
    neural_config = neural_config or NeuralOuterLoopConfig()
    beam_results = beam_symbolic_search(target_moments, train_env_builders, validation_env_builders, test_env_builders, n_agents, beam_config, train_episodes, seed, weights, agent_kind, tabular_config, deep_config, greedy_tail_frac)
    evo_results = evolutionary_symbolic_search(target_moments, train_env_builders, validation_env_builders, test_env_builders, n_agents, evo_config, train_episodes, seed + 10_000, weights, agent_kind, tabular_config, deep_config, greedy_tail_frac)
    neural_results = neural_utility_search(target_moments, train_env_builders, validation_env_builders, test_env_builders, n_agents, neural_config, train_episodes, seed + 20_000, weights, agent_kind, tabular_config, deep_config, greedy_tail_frac)
    all_results = beam_results[: max(1, beam_config.beam_width)] + evo_results[: max(1, evo_config.population_size // 2)] + neural_results[: max(1, neural_config.population_size // 2)]
    # Distill top neural candidate, then evaluate the distilled symbolic model inside the full environment loop.
    top_neural = neural_results[0]
    expression_library = build_expression_library(beam_config.base_features, include_ratio=beam_config.include_ratio)[: int(max(beam_config.max_library_size, evo_config.max_library_size))]
    distill = distill_neural_to_symbolic(
        top_neural.candidate.utility_specs[0].params,
        expression_library=expression_library,
        n_samples=384,
        seed=seed + 30_000,
        beam_width=max(beam_config.beam_width, 3),
        max_terms=max(beam_config.max_terms, evo_config.max_terms),
        complexity_penalty=min(beam_config.complexity_penalty, evo_config.complexity_penalty),
    )
    target_train, target_val, target_test = _split_targets(target_moments, train_env_builders, validation_env_builders, test_env_builders)
    distilled_spec = UtilitySpec("symbolic_compositional", {"weights": distill["weights"]})
    ctx = EvaluationContext(target_train, target_val, target_test, train_env_builders, validation_env_builders, test_env_builders, n_agents, train_episodes, weights, agent_kind, tabular_config, deep_config, beam_config.complexity_penalty, greedy_tail_frac)
    distilled_res = _evaluate_spec(distilled_spec, ctx, seed + 31_000, prefix="distilled")
    all_results.append(distilled_res)
    all_results.sort(key=lambda r: r.score)
    ranking = _to_frame(all_results)
    return IntegratedSearchOutput(
        ranking=ranking,
        best_result=all_results[0],
        distillation=distill,
        beam_ranking=_to_frame(beam_results),
        evolutionary_ranking=_to_frame(evo_results),
        neural_ranking=_to_frame(neural_results),
    )
