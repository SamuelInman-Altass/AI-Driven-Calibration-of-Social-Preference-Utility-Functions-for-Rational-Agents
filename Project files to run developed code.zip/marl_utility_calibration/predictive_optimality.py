from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Sequence

import numpy as np
import pandas as pd

from .agents import AgentConfig, DeepAgentConfig, UtilitySpec
from .calibration import PopulationCandidate, evaluate_candidate
from .integrated_search import (
    BeamSearchConfig,
    EvolutionarySearchConfig,
    beam_symbolic_search,
    evolutionary_symbolic_search,
)
from .tracking import moment_loss
from .utility_search import SearchConfig, search_best_utility


APPROXIMATE_PREDICTIVE_OPTIMALITY_DEFINITION = (
    "A utility specification is an approximate predictive optimum if it is the best-scoring candidate found by multi-start "
    "search over richer symbolic hypothesis classes under regularized held-out behavioral prediction error."
)

RICH_CLASS_INTERPRETATION = (
    "Reported winners are approximate predictive optima in richer symbolic classes. "
    "A finite restricted exhaustive search is retained only as a reference benchmark, not as the primary selection target."
)


@dataclass(frozen=True)
class PredictiveOptimalConfig:
    complexity_penalty: float = 0.02
    neural_complexity_penalty: float = 0.0001
    n_restarts: int = 1
    n_bootstrap: int = 30
    top_k_per_method: int = 1
    train_episodes: int = 18
    exhaustive_max_terms: int = 2
    exhaustive_terms: Sequence[str] = ("own_payoff", "others_mean", "disadv_ineq", "adv_ineq")
    exhaustive_weight_grid: Sequence[float] = (-1.0, -0.5, -0.25, 0.25, 0.35, 0.5, 1.0)
    significance_alpha: float = 0.05
    finalist_count: int = 3
    finalist_repeats: int = 30
    finalist_eval_min_episodes: int = 80
    bootstrap_eval_min_episodes: int = 80
    greedy_tail_frac: float = 0.2
    ablation_beam_widths: Sequence[int] = (1, 2)
    ablation_complexity_penalties: Sequence[float] = (0.01, 0.02, 0.05)
    ablation_episode_budgets: Sequence[int] = (60, 120)
    run_ablation_sweep: bool = True


@dataclass
class PredictiveOptimalOutput:
    definition: str
    rich_class_interpretation: str
    overall_ranking: pd.DataFrame
    bootstrap_summary: pd.DataFrame
    significance_table: pd.DataFrame
    exhaustive_restricted_ranking: pd.DataFrame
    cross_method_winners: pd.DataFrame
    agreement_summary: pd.DataFrame
    rich_class_summary: pd.DataFrame
    optimality_certificates: pd.DataFrame
    selected_candidate: str
    selected_signature: str | None
    restart_winner_frequency: pd.DataFrame
    method_consensus_summary: pd.DataFrame
    finalist_summary: pd.DataFrame
    finalist_repeated_test: pd.DataFrame
    finalist_pairwise_tests: pd.DataFrame
    finalist_winner_frequency: pd.DataFrame
    restart_variance_summary: pd.DataFrame
    ablation_summary: pd.DataFrame


def _selection_base_loss(row_or_result) -> float:
    validation_loss = getattr(row_or_result, "validation_loss", None) if not isinstance(row_or_result, dict) else row_or_result.get("validation_loss")
    if validation_loss is not None and pd.notna(validation_loss):
        return float(validation_loss)
    return float("inf")


def _regularized_selection_score(base_loss: float, complexity: float, complexity_penalty: float) -> float:
    return float(base_loss + complexity_penalty * complexity)


def _min_achievable_smoothed_p(n_trials: int) -> float:
    return float(1.0 / (max(int(n_trials), 0) + 1.0))


def _candidate_signature(spec: UtilitySpec) -> str:
    if spec.family in {"compositional", "symbolic_compositional"}:
        weights = spec.params.get("weights", {})
        return spec.family + ":" + ",".join(f"{k}={float(v):.3g}" for k, v in sorted(weights.items()))
    if spec.family == "gp_symbolic":
        return spec.family + ":" + str(spec.params.get("tree", {}))[:120]
    if spec.family == "neural":
        return spec.family + ":hidden"
    return spec.family + ":" + ",".join(f"{k}={v}" for k, v in sorted(spec.params.items()))


def _evaluate_result_test_only(
    candidate: PopulationCandidate,
    target_test: Dict[str, float],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    train_episodes: int,
    seed: int,
    weights: Dict[str, float] | None,
    agent_kind: str,
    tabular_config: AgentConfig | None,
    deep_config: DeepAgentConfig | None,
    min_eval_episodes: int = 80,
    greedy_tail_frac: float = 0.2,
) -> float:
    if not test_env_builders or not target_test:
        return np.nan
    effective_episodes = max(int(train_episodes), int(min_eval_episodes))
    pred = evaluate_candidate(
        candidate,
        test_env_builders,
        train_episodes=effective_episodes,
        seed=seed,
        agent_kind=agent_kind,
        tabular_config=tabular_config,
        deep_config=deep_config,
        greedy_tail_frac=greedy_tail_frac,
    )
    return float(moment_loss(pred, target_test, weights=weights))


def _run_all_methods_once(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    n_agents: int,
    cfg: PredictiveOptimalConfig,
    seed: int,
    weights: Dict[str, float] | None,
    agent_kind: str,
    tabular_config: AgentConfig | None,
    deep_config: DeepAgentConfig | None,
):
    print(f"[benchmark] search suite start seed={seed} train_episodes={cfg.train_episodes}", flush=True)
    print("[benchmark] method=beam start", flush=True)
    beam = beam_symbolic_search(
        target_moments, train_env_builders, validation_env_builders, test_env_builders, n_agents,
        BeamSearchConfig(complexity_penalty=cfg.complexity_penalty, max_terms=1), cfg.train_episodes, seed + 100,
        weights, agent_kind, tabular_config, deep_config, cfg.greedy_tail_frac,
    )[: cfg.top_k_per_method]
    print(f"[benchmark] method=beam done candidates={len(beam)}", flush=True)
    print("[benchmark] method=evolutionary start", flush=True)
    evo = evolutionary_symbolic_search(
        target_moments, train_env_builders, validation_env_builders, test_env_builders, n_agents,
        EvolutionarySearchConfig(complexity_penalty=cfg.complexity_penalty), cfg.train_episodes, seed + 200,
        weights, agent_kind, tabular_config, deep_config, cfg.greedy_tail_frac,
    )[: cfg.top_k_per_method]
    print(f"[benchmark] method=evolutionary done candidates={len(evo)}", flush=True)
    print("[benchmark] method=exhaustive start", flush=True)
    exhaustive = search_best_utility(
        target_moments=target_moments,
        train_env_builders=train_env_builders,
        validation_env_builders=validation_env_builders,
        test_env_builders=test_env_builders,
        n_agents=n_agents,
        search_config=SearchConfig(
            terms=tuple(cfg.exhaustive_terms),
            max_terms=cfg.exhaustive_max_terms,
            weight_grid=tuple(cfg.exhaustive_weight_grid),
            complexity_penalty=cfg.complexity_penalty,
        ),
        include_fixed_baselines=True,
        train_episodes=cfg.train_episodes,
        seed=seed + 500,
        weights=weights,
        agent_kind=agent_kind,
        tabular_config=tabular_config,
        deep_config=deep_config,
        evaluate_top_k_on_test=cfg.top_k_per_method,
        greedy_tail_frac=cfg.greedy_tail_frac,
    )[: cfg.top_k_per_method]
    print(f"[benchmark] method=exhaustive done candidates={len(exhaustive)}", flush=True)
    print("[benchmark] search suite complete", flush=True)
    return {"beam": beam, "evolutionary": evo, "exhaustive": exhaustive}


def _flatten_method_results(method_results, restart_idx: int, complexity_penalty: float, neural_complexity_penalty: float):
    rows: List[Dict[str, object]] = []
    for method, results in method_results.items():
        for rank, r in enumerate(results, start=1):
            spec = r.candidate.utility_specs[0]
            signature = _candidate_signature(spec)
            base_loss = _selection_base_loss(r)
            effective_penalty = complexity_penalty
            regularized_score = _regularized_selection_score(base_loss, r.complexity, effective_penalty)
            rows.append({
                "restart": restart_idx,
                "method": method,
                "rank_within_method": rank,
                "candidate": r.candidate.name,
                "signature": signature,
                "family": spec.family,
                "train_loss": float(r.train_loss),
                "validation_loss": float(r.validation_loss),
                "test_loss": np.nan if r.test_loss is None else float(r.test_loss),
                "complexity": int(r.complexity),
                "predictive_score": float(base_loss),
                "selection_score": float(regularized_score),
                "predictive_optimal_score": float(regularized_score),
                "optimality_type": "reference_restricted" if method == "exhaustive" else "approximate_rich",
                "searched_hypothesis_class": "restricted_finite_reference" if method == "exhaustive" else "rich_symbolic",
            })
    return rows


def _bootstrap_significance(
    selected_candidate: PopulationCandidate,
    comparator_candidates: List[PopulationCandidate],
    target_test: Dict[str, float],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    cfg: PredictiveOptimalConfig,
    base_seed: int,
    weights: Dict[str, float] | None,
    agent_kind: str,
    tabular_config: AgentConfig | None,
    deep_config: DeepAgentConfig | None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    sig_rows = []
    selected_losses = []
    for b in range(cfg.n_bootstrap):
        loss = _evaluate_result_test_only(selected_candidate, target_test, test_env_builders, cfg.train_episodes, base_seed + b, weights, agent_kind, tabular_config, deep_config, min_eval_episodes=cfg.bootstrap_eval_min_episodes, greedy_tail_frac=cfg.greedy_tail_frac)
        selected_losses.append(loss)
        rows.append({"bootstrap": b, "candidate": selected_candidate.name, "test_loss": loss})
    selected_losses = np.asarray(selected_losses, dtype=float)

    for comp in comparator_candidates:
        comp_losses = []
        for b in range(cfg.n_bootstrap):
            loss = _evaluate_result_test_only(comp, target_test, test_env_builders, cfg.train_episodes, base_seed + b, weights, agent_kind, tabular_config, deep_config, min_eval_episodes=cfg.bootstrap_eval_min_episodes, greedy_tail_frac=cfg.greedy_tail_frac)
            comp_losses.append(loss)
            rows.append({"bootstrap": b, "candidate": comp.name, "test_loss": loss})
        comp_arr = np.asarray(comp_losses, dtype=float)
        diff = comp_arr - selected_losses
        diff = diff[np.isfinite(diff)]
        if diff.size:
            p_one_sided = float((1.0 + np.sum(diff <= 0.0)) / (diff.size + 1.0))
            min_p = _min_achievable_smoothed_p(diff.size)
            sig_rows.append({
                "selected_candidate": selected_candidate.name,
                "comparator": comp.name,
                "mean_selected_test_loss": float(np.nanmean(selected_losses)),
                "mean_comparator_test_loss": float(np.nanmean(comp_arr)),
                "mean_gap_comparator_minus_selected": float(np.nanmean(diff)),
                "p_one_sided_selected_better": p_one_sided,
                "min_achievable_p_with_current_bootstrap": min_p,
                "alpha_resolution_sufficient": bool(min_p < cfg.significance_alpha),
                "selected_better_at_alpha": bool(min_p < cfg.significance_alpha and p_one_sided < cfg.significance_alpha),
            })
    return pd.DataFrame(rows), pd.DataFrame(sig_rows)


def _make_certificates(overall: pd.DataFrame, exhaustive_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    restricted_signature = None
    restricted_candidate = None
    restricted_score = np.nan
    if not exhaustive_df.empty:
        restricted_signature = str(exhaustive_df.iloc[0]["signature"])
        restricted_candidate = str(exhaustive_df.iloc[0]["candidate"])
        restricted_score = float(exhaustive_df.iloc[0]["predictive_optimal_score"])

    cert_rows = []
    for _, row in overall.iterrows():
        signature = str(row["signature"])
        candidate = str(row["candidate"])
        mean_test = row.get("mean_test_loss", np.nan)
        mean_val = row.get("mean_validation_loss", np.nan)
        score = float(row["predictive_optimal_score"])
        is_exact = bool(signature == restricted_signature) if restricted_signature is not None else False
        cert_rows.append({
            "candidate": candidate,
            "signature": signature,
            "family": row.get("family"),
            "predictive_optimal_score": score,
            "mean_test_loss": mean_test,
            "mean_validation_loss": mean_val,
            "mean_complexity": row.get("mean_complexity", np.nan),
            "optimality_status": "reference_restricted" if is_exact else "approximate_rich",
            "certificate_scope": "finite_restricted_reference" if is_exact else "rich_symbolic",
            "is_reference_restricted_optimum": is_exact,
            "matches_restricted_global_optimum": is_exact,
            "restricted_global_optimum_candidate": restricted_candidate,
            "restricted_global_optimum_signature": restricted_signature,
            "restricted_global_optimum_score": restricted_score,
            "gap_to_restricted_global_optimum": np.nan if np.isnan(restricted_score) else score - restricted_score,
        })
    cert_df = pd.DataFrame(cert_rows)

    selected = cert_df.iloc[0] if not cert_df.empty else None
    summary = pd.DataFrame([{
        "selected_candidate": None if selected is None else selected["candidate"],
        "selected_signature": None if selected is None else selected["signature"],
        "selected_status": None if selected is None else selected["optimality_status"],
        "selected_scope": None if selected is None else selected["certificate_scope"],
        "selected_matches_restricted_global_optimum": None if selected is None else bool(selected["matches_restricted_global_optimum"]),
        "restricted_global_optimum_candidate": restricted_candidate,
        "restricted_global_optimum_signature": restricted_signature,
        "restricted_global_optimum_score": restricted_score,
        "interpretation": (
            "Selected model coincides with the restricted exhaustive reference winner but is still reported here as a rich-class approximate predictive optimum."
            if selected is not None and bool(selected["matches_restricted_global_optimum"])
            else "Selected model is an approximate predictive optimum in the richer symbolic search space; the restricted exhaustive winner is reported separately as a reference benchmark."
        ),
    }])
    return cert_df, summary


def _align_certificates_to_selected(cert_df: pd.DataFrame, selected_name: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    if cert_df.empty:
        return cert_df, pd.DataFrame([{
            "selected_candidate": selected_name,
            "selected_signature": None,
            "selected_status": None,
            "selected_scope": None,
            "selected_matches_restricted_global_optimum": None,
            "restricted_global_optimum_candidate": None,
            "restricted_global_optimum_signature": None,
            "restricted_global_optimum_score": np.nan,
            "interpretation": "No certificate rows available.",
        }])
    cert_df = cert_df.copy()
    cert_df["is_final_selected"] = cert_df["candidate"].astype(str) == str(selected_name)
    cert_df = cert_df.sort_values(["is_final_selected", "predictive_optimal_score", "mean_test_loss", "mean_validation_loss"], ascending=[False, True, True, True], na_position="last").reset_index(drop=True)
    selected = cert_df[cert_df["is_final_selected"]].iloc[0] if cert_df["is_final_selected"].any() else cert_df.iloc[0]
    summary = pd.DataFrame([{
        "selected_candidate": selected["candidate"],
        "selected_signature": selected["signature"],
        "selected_status": selected["optimality_status"],
        "selected_scope": selected["certificate_scope"],
        "selected_matches_restricted_global_optimum": bool(selected["matches_restricted_global_optimum"]),
        "restricted_global_optimum_candidate": selected.get("restricted_global_optimum_candidate"),
        "restricted_global_optimum_signature": selected.get("restricted_global_optimum_signature"),
        "restricted_global_optimum_score": selected.get("restricted_global_optimum_score", np.nan),
        "interpretation": (
            "Selected model coincides with the restricted exhaustive reference winner but is still reported here as a rich-class approximate predictive optimum."
            if bool(selected["matches_restricted_global_optimum"])
            else "Selected model is the final repeated-test winner and is reported as the benchmark selection; the restricted exhaustive winner is reported separately as a reference benchmark."
        ),
    }])
    return cert_df, summary


def _build_restart_winner_frequency(winners_df: pd.DataFrame) -> pd.DataFrame:
    if winners_df.empty:
        return pd.DataFrame()
    out = winners_df.groupby(["method", "winner", "signature", "family", "optimality_type"], as_index=False).agg(
        restart_wins=("restart", "count"),
        mean_validation_loss=("validation_loss", "mean"),
        mean_test_loss=("test_loss", "mean"),
        mean_predictive_optimal_score=("predictive_optimal_score", "mean"),
    )
    restart_counts = winners_df.groupby("method")["restart"].nunique().to_dict()
    out["restart_win_rate"] = out.apply(lambda r: r["restart_wins"] / float(restart_counts.get(r["method"], 1)), axis=1)
    return out.sort_values(["method", "restart_win_rate", "mean_predictive_optimal_score", "mean_test_loss"], ascending=[True, False, True, True]).reset_index(drop=True)


def _build_method_consensus_summary(winners_df: pd.DataFrame) -> pd.DataFrame:
    if winners_df.empty:
        return pd.DataFrame()
    n_methods = max(1, winners_df["method"].nunique())
    summary = winners_df.groupby(["signature", "family"], as_index=False).agg(
        methods_selecting=("method", lambda s: ";".join(sorted(set(map(str, s))))),
        unique_methods=("method", lambda s: int(len(set(map(str, s))))),
        total_selections=("restart", "count"),
        mean_validation_loss=("validation_loss", "mean"),
        std_validation_loss=("validation_loss", "std"),
        mean_test_loss=("test_loss", "mean"),
        std_test_loss=("test_loss", "std"),
        mean_predictive_optimal_score=("predictive_optimal_score", "mean"),
    )
    summary["consensus_rate"] = summary["unique_methods"] / float(n_methods)
    return summary.sort_values(["consensus_rate", "total_selections", "mean_predictive_optimal_score", "mean_test_loss"], ascending=[False, False, True, True]).reset_index(drop=True)



def _collect_finalists(overall: pd.DataFrame, exhaustive_df: pd.DataFrame, finalist_count: int) -> pd.DataFrame:
    rich = overall.head(finalist_count).copy()
    if not exhaustive_df.empty:
        ref = exhaustive_df.head(1).copy()
        for col in rich.columns:
            if col not in ref.columns:
                ref[col] = np.nan
        ref = ref[rich.columns]
        rich = pd.concat([rich, ref], ignore_index=True)
    return rich.drop_duplicates(subset=["signature"], keep="first").reset_index(drop=True)


def _repeated_test_eval(
    finalist_df: pd.DataFrame,
    candidate_map: Dict[str, PopulationCandidate],
    target_test: Dict[str, float],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    cfg: PredictiveOptimalConfig,
    base_seed: int,
    weights: Dict[str, float] | None,
    agent_kind: str,
    tabular_config: AgentConfig | None,
    deep_config: DeepAgentConfig | None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rows = []
    for _, row in finalist_df.iterrows():
        cand = candidate_map.get(str(row["candidate"]))
        if cand is None:
            continue
        for rep in range(cfg.finalist_repeats):
            eval_seed = base_seed + rep * 101
            loss = _evaluate_result_test_only(
                cand, target_test, test_env_builders, cfg.train_episodes, eval_seed,
                weights, agent_kind, tabular_config, deep_config, cfg.finalist_eval_min_episodes, cfg.greedy_tail_frac,
            )
            rows.append({
                "candidate": cand.name,
                "signature": _candidate_signature(cand.utility_specs[0]),
                "repeat": rep,
                "seed": eval_seed,
                "test_loss": loss,
            })
    repeated = pd.DataFrame(rows)
    if repeated.empty:
        return repeated, pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    summary = repeated.groupby(["candidate", "signature"], as_index=False).agg(
        repeated_test_mean=("test_loss", "mean"),
        repeated_test_std=("test_loss", "std"),
        repeated_test_var=("test_loss", "var"),
        repeats=("test_loss", "count"),
    )
    summary["repeated_test_se"] = summary["repeated_test_std"] / np.sqrt(summary["repeats"].clip(lower=1))
    z = 1.96
    summary["ci95_low"] = summary["repeated_test_mean"] - z * summary["repeated_test_se"]
    summary["ci95_high"] = summary["repeated_test_mean"] + z * summary["repeated_test_se"]
    summary = summary.sort_values(["repeated_test_mean", "repeated_test_std"]).reset_index(drop=True)

    pairwise_rows = []
    finalists = summary["candidate"].tolist()
    if finalists:
        selected = finalists[0]
        selected_df = repeated[repeated["candidate"] == selected][["repeat", "test_loss"]].rename(columns={"test_loss": "selected_test_loss"})
        for comp in finalists[1:]:
            comp_df = repeated[repeated["candidate"] == comp][["repeat", "test_loss"]].rename(columns={"test_loss": "comparator_test_loss"})
            merged = selected_df.merge(comp_df, on="repeat", how="inner")
            if merged.empty:
                continue
            diff = merged["comparator_test_loss"] - merged["selected_test_loss"]
            n = len(diff)
            mean_diff = float(diff.mean())
            sd = float(diff.std(ddof=1)) if n > 1 else float('nan')
            se = sd / np.sqrt(n) if n > 1 and sd == sd else float('nan')
            ci_low = mean_diff - z * se if se == se else float('nan')
            ci_high = mean_diff + z * se if se == se else float('nan')
            p_one_sided = float((1.0 + np.sum(diff <= 0.0)) / (n + 1.0))
            min_p = _min_achievable_smoothed_p(n)
            pairwise_rows.append({
                "selected_candidate": selected,
                "comparator": comp,
                "n_repeats": n,
                "mean_selected_test_loss": float(merged["selected_test_loss"].mean()),
                "mean_comparator_test_loss": float(merged["comparator_test_loss"].mean()),
                "mean_gap_comparator_minus_selected": mean_diff,
                "gap_ci95_low": ci_low,
                "gap_ci95_high": ci_high,
                "p_one_sided_selected_better": p_one_sided,
                "min_achievable_p_with_current_repeats": min_p,
                "alpha_resolution_sufficient": bool(min_p < cfg.significance_alpha),
                "selected_better_at_alpha": bool(min_p < cfg.significance_alpha and p_one_sided < cfg.significance_alpha),
            })

    winner_rows = []
    for rep, grp in repeated.groupby("repeat"):
        best = grp.sort_values(["test_loss", "candidate"]).iloc[0]
        winner_rows.append({"repeat": rep, "winner": best["candidate"], "signature": best["signature"], "test_loss": best["test_loss"]})
    winner_freq = pd.DataFrame(winner_rows).groupby(["winner", "signature"], as_index=False).agg(
        wins=("repeat", "count"),
        mean_winning_test_loss=("test_loss", "mean"),
    )
    winner_freq["win_rate"] = winner_freq["wins"] / float(repeated["repeat"].nunique())
    winner_freq = winner_freq.sort_values(["win_rate", "mean_winning_test_loss"], ascending=[False, True]).reset_index(drop=True)

    return repeated, summary, pd.DataFrame(pairwise_rows), winner_freq


def _run_ablation_sweep(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    n_agents: int,
    cfg: PredictiveOptimalConfig,
    seed: int,
    weights: Dict[str, float] | None,
    agent_kind: str,
    tabular_config: AgentConfig | None,
    deep_config: DeepAgentConfig | None,
) -> pd.DataFrame:
    rows = []
    for beam_width in cfg.ablation_beam_widths:
        for penalty in cfg.ablation_complexity_penalties:
            for episodes in cfg.ablation_episode_budgets:
                beam_cfg = BeamSearchConfig(complexity_penalty=penalty, beam_width=beam_width)
                results = beam_symbolic_search(
                    target_moments, train_env_builders, validation_env_builders, test_env_builders, n_agents,
                    beam_cfg, episodes, seed + int(1000 * penalty) + 10 * beam_width + episodes,
                    weights, agent_kind, tabular_config, deep_config,
                )[:1]
                if not results:
                    continue
                r = results[0]
                rows.append({
                    "beam_width": beam_width,
                    "complexity_penalty": penalty,
                    "episode_budget": episodes,
                    "candidate": r.candidate.name,
                    "signature": _candidate_signature(r.candidate.utility_specs[0]),
                    "validation_loss": float(r.validation_loss),
                    "test_loss": np.nan if r.test_loss is None else float(r.test_loss),
                    "complexity": int(r.complexity),
                    "predictive_optimal_score": float((r.test_loss if r.test_loss is not None else r.validation_loss) + penalty * r.complexity),
                })
    return pd.DataFrame(rows).sort_values(["beam_width", "complexity_penalty", "episode_budget", "predictive_optimal_score"]).reset_index(drop=True) if rows else pd.DataFrame()




def _build_restart_variance_summary(all_df: pd.DataFrame) -> pd.DataFrame:
    if all_df.empty:
        return pd.DataFrame()
    out = all_df.groupby(["candidate", "signature", "family", "method"], as_index=False).agg(
        mean_validation_loss=("validation_loss", "mean"),
        std_validation_loss=("validation_loss", "std"),
        var_validation_loss=("validation_loss", "var"),
        mean_test_loss=("test_loss", "mean"),
        std_test_loss=("test_loss", "std"),
        var_test_loss=("test_loss", "var"),
        mean_complexity=("complexity", "mean"),
        restarts=("restart", "nunique"),
    )
    return out.sort_values(["method", "mean_test_loss", "mean_validation_loss"]).reset_index(drop=True)



def _collapse_candidates_by_signature(all_df: pd.DataFrame) -> pd.DataFrame:
    if all_df.empty:
        return pd.DataFrame()
    sorted_df = all_df.sort_values(
        ["predictive_optimal_score", "predictive_score", "validation_loss", "test_loss", "complexity", "candidate"],
        ascending=[True, True, True, True, True, True],
        na_position="last",
    ).reset_index(drop=True)
    representatives = sorted_df.drop_duplicates(subset=["signature"], keep="first")[["signature", "candidate"]]
    agg = all_df.groupby(["signature", "family"], as_index=False).agg(
        mean_predictive_optimal_score=("predictive_optimal_score", "mean"),
        mean_validation_loss=("validation_loss", "mean"),
        std_validation_loss=("validation_loss", "std"),
        mean_test_loss=("test_loss", "mean"),
        std_test_loss=("test_loss", "std"),
        mean_complexity=("complexity", "mean"),
        support=("signature", "count"),
        unique_methods=("method", lambda s: int(pd.Series(s).nunique())),
        unique_candidate_names=("candidate", lambda s: int(pd.Series(s).nunique())),
    )
    out = agg.rename(columns={"mean_predictive_optimal_score": "predictive_optimal_score"}).merge(representatives, on="signature", how="left")
    return out.sort_values(["predictive_optimal_score", "mean_test_loss", "mean_validation_loss", "mean_complexity", "candidate"], ascending=[True, True, True, True, True]).reset_index(drop=True)

def run_predictive_optimality_benchmark(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    n_agents: int,
    config: PredictiveOptimalConfig | None = None,
    seed: int = 0,
    weights: Dict[str, float] | None = None,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
) -> PredictiveOptimalOutput:
    cfg = config or PredictiveOptimalConfig()
    finalist_extra_calls = int(cfg.finalist_count) * int(cfg.finalist_repeats)
    bootstrap_extra_calls = int(cfg.n_bootstrap) * int(cfg.finalist_count)
    print(
        f"[benchmark] evaluation budget note main_train_episodes={cfg.train_episodes} finalist_repeats={cfg.finalist_repeats} finalist_eval_min_episodes={cfg.finalist_eval_min_episodes} n_bootstrap={cfg.n_bootstrap} bootstrap_eval_min_episodes={cfg.bootstrap_eval_min_episodes} finalist_extra_calls≈{finalist_extra_calls} bootstrap_extra_calls≈{bootstrap_extra_calls}",
        flush=True,
    )
    all_rows: List[Dict[str, object]] = []
    winners: List[Dict[str, object]] = []
    candidate_map: Dict[str, PopulationCandidate] = {}

    print(f"[benchmark] starting predictive optimality benchmark restarts={cfg.n_restarts}", flush=True)
    for restart in range(cfg.n_restarts):
        print(f"[benchmark] restart {restart + 1}/{cfg.n_restarts} start", flush=True)
        method_results = _run_all_methods_once(
            target_moments, train_env_builders, validation_env_builders, test_env_builders, n_agents, cfg,
            seed + restart * 1000, weights, agent_kind, tabular_config, deep_config,
        )
        all_rows.extend(_flatten_method_results(method_results, restart, cfg.complexity_penalty, cfg.neural_complexity_penalty))
        for _method, _results in method_results.items():
            for _r in _results:
                candidate_map.setdefault(_r.candidate.name, _r.candidate)
        print(f"[benchmark] restart {restart + 1}/{cfg.n_restarts} collected methods={list(method_results.keys())}", flush=True)
        for method, results in method_results.items():
            if results:
                best = results[0]
                spec = best.candidate.utility_specs[0]
                winner_base_loss = _selection_base_loss(best)
                winner_penalty = cfg.complexity_penalty
                winner_score = _regularized_selection_score(winner_base_loss, best.complexity, winner_penalty)
                winners.append({
                    "restart": restart,
                    "method": method,
                    "winner": best.candidate.name,
                    "signature": _candidate_signature(spec),
                    "family": spec.family,
                    "validation_loss": best.validation_loss,
                    "test_loss": np.nan if best.test_loss is None else best.test_loss,
                    "complexity": best.complexity,
                    "predictive_optimal_score": winner_score,
                    "optimality_type": "reference_restricted" if method == "exhaustive" else "approximate_rich",
                })

    all_df = pd.DataFrame(all_rows)
    if all_df.empty:
        raise ValueError("No search results produced.")

    overall = _collapse_candidates_by_signature(all_df)
    restricted_signatures = set(all_df.loc[all_df["method"] == "exhaustive", "signature"].astype(str))
    rich_candidates = overall[~overall["signature"].astype(str).isin(restricted_signatures)].reset_index(drop=True)
    if rich_candidates.empty:
        rich_candidates = overall.copy()
    selected_name = str(rich_candidates.iloc[0]["candidate"])
    selected_signature = str(rich_candidates.iloc[0]["signature"])

    winners_df = pd.DataFrame(winners)
    agreement = winners_df.groupby(["method", "signature", "family", "optimality_type"], as_index=False).agg(
        selection_count=("winner", "count"),
        mean_predictive_optimal_score=("predictive_optimal_score", "mean"),
    )
    agreement["selection_rate_within_method"] = agreement["selection_count"] / float(cfg.n_restarts)
    agreement = agreement.sort_values(["method", "selection_rate_within_method", "signature"], ascending=[True, False, True]).reset_index(drop=True)
    restart_winner_frequency = _build_restart_winner_frequency(winners_df)
    method_consensus_summary = _build_method_consensus_summary(winners_df)

    target_test = {k: v for k, v in target_moments.items() if any(k.startswith(f"{name}::") for name in (test_env_builders or {}).keys())}

    exhaustive_df = _collapse_candidates_by_signature(all_df[all_df["method"] == "exhaustive"].copy())
    exhaustive_df["global_optimum_in_restricted_space"] = exhaustive_df.index == 0

    cert_df, exact_vs_approx_summary = _make_certificates(rich_candidates, exhaustive_df)

    finalist_candidates = _collect_finalists(rich_candidates, exhaustive_df, cfg.finalist_count)
    repeated_test_df, finalist_eval_summary, finalist_pairwise_df, finalist_winner_frequency = _repeated_test_eval(
        finalist_candidates,
        candidate_map,
        target_test,
        test_env_builders,
        cfg,
        seed + 12000,
        weights,
        agent_kind,
        tabular_config,
        deep_config,
    )
    if not finalist_eval_summary.empty:
        selected_name = str(finalist_eval_summary.iloc[0]["candidate"])
        selected_signature = str(finalist_eval_summary.iloc[0]["signature"])
    cert_df, exact_vs_approx_summary = _align_certificates_to_selected(cert_df, selected_name)

    comparator_candidates = []
    if not finalist_candidates.empty:
        for _, row in finalist_candidates.iterrows():
            cand_name = str(row["candidate"])
            if cand_name == selected_name:
                continue
            cand = candidate_map.get(cand_name)
            if cand is not None:
                comparator_candidates.append(cand)
    selected_candidate_obj = candidate_map.get(selected_name)
    if selected_candidate_obj is not None and comparator_candidates:
        print("[benchmark] bootstrap significance on finalists start", flush=True)
        bootstrap_df, sig_df = _bootstrap_significance(
            selected_candidate_obj,
            comparator_candidates,
            target_test,
            test_env_builders,
            cfg,
            seed + 9000,
            weights,
            agent_kind,
            tabular_config,
            deep_config,
        )
    else:
        bootstrap_df = pd.DataFrame()
        sig_df = pd.DataFrame()

    if cfg.run_ablation_sweep:
        print("[benchmark] ablation sweep start", flush=True)
        ablation_df = _run_ablation_sweep(
            target_moments,
            train_env_builders,
            validation_env_builders,
            test_env_builders,
            n_agents,
            cfg,
            seed + 15000,
            weights,
            agent_kind,
            tabular_config,
            deep_config,
        )
    else:
        print("[benchmark] ablation sweep skipped by config", flush=True)
        ablation_df = pd.DataFrame()

    restart_variance_summary = _build_restart_variance_summary(all_df)

    return PredictiveOptimalOutput(
        definition=APPROXIMATE_PREDICTIVE_OPTIMALITY_DEFINITION,
        rich_class_interpretation=RICH_CLASS_INTERPRETATION,
        overall_ranking=rich_candidates,
        bootstrap_summary=bootstrap_df,
        significance_table=sig_df,
        exhaustive_restricted_ranking=exhaustive_df,
        cross_method_winners=winners_df,
        agreement_summary=agreement,
        rich_class_summary=exact_vs_approx_summary,
        optimality_certificates=cert_df,
        selected_candidate=selected_name,
        selected_signature=selected_signature,
        restart_winner_frequency=restart_winner_frequency,
        method_consensus_summary=method_consensus_summary,
        finalist_summary=finalist_eval_summary if not finalist_eval_summary.empty else finalist_candidates,
        finalist_repeated_test=repeated_test_df,
        finalist_pairwise_tests=finalist_pairwise_df if not finalist_pairwise_df.empty else sig_df,
        finalist_winner_frequency=finalist_winner_frequency,
        restart_variance_summary=restart_variance_summary,
        ablation_summary=ablation_df,
    )
