from __future__ import annotations

import itertools
from dataclasses import dataclass
import warnings
from typing import Callable, Dict, List, Sequence

import pandas as pd

from .agents import AgentConfig, DeepAgentConfig, UtilityModel, UtilitySpec
from .calibration import PopulationCandidate, evaluate_candidate
from .tracking import moment_loss
from .utility_expressions import BASE_FEATURES, build_expression_library
from .utility_search import SearchResult


@dataclass(frozen=True)
class SymbolicSearchConfig:
    base_features: Sequence[str] = BASE_FEATURES
    max_expressions: int = 2
    weight_grid: Sequence[float] = (-1.0, -0.5, -0.25, 0.25, 0.5, 1.0)
    complexity_penalty: float = 0.03
    include_ratio: bool = False
    include_fixed_baselines: bool = True
    max_library_size: int | None = 40
    max_candidates: int | None = 25000
    missing_moment_penalty: float = 1.0


def symbolic_spec(weights: Dict[str, float]) -> UtilitySpec:
    sparse = {k: float(v) for k, v in weights.items() if abs(float(v)) > 1e-12}
    return UtilitySpec("symbolic_compositional", {"weights": sparse})


def fixed_baseline_specs() -> List[UtilitySpec]:
    return [
        UtilitySpec("selfish", {"selfish_weight": 1.0}),
        UtilitySpec("social_tradeoff", {"selfish_weight": 1.0, "altruism_weight": 1.0, "other_payoff_aggregation": "mean"}),
        UtilitySpec("inequity_aversion", {"selfish_weight": 1.0, "alpha": 0.8, "beta": 0.3}),
        UtilitySpec("compositional", {"weights": {"own_payoff": 1.0, "others_mean": 0.3, "disadv_ineq": -0.5}}),
    ]


def candidate_from_spec(spec: UtilitySpec, n_agents: int, prefix: str = "symbolic") -> PopulationCandidate:
    if spec.family == "symbolic_compositional":
        suffix = "_".join(f"{k}={v:g}" for k, v in sorted(spec.params.get("weights", {}).items()))
        name = f"{prefix}_{suffix}" if suffix else prefix
    elif spec.family == "compositional":
        suffix = "_".join(f"{k}={v:g}" for k, v in sorted(spec.params.get("weights", {}).items()))
        name = f"{prefix}_linear_{suffix}" if suffix else f"{prefix}_linear"
    else:
        name = f"{prefix}_{spec.family}"
    return PopulationCandidate(name=name, utility_specs=[spec for _ in range(n_agents)])


def split_target(flat_moments: Dict[str, float], env_builders: Dict[str, Callable[[], object]]) -> Dict[str, float]:
    return {k: v for k, v in flat_moments.items() if any(k.startswith(f"{name}::") for name in env_builders.keys())}


def generate_symbolic_specs(config: SymbolicSearchConfig) -> List[UtilitySpec]:
    expr_library = build_expression_library(config.base_features, include_ratio=config.include_ratio)
    if config.max_library_size is not None:
        expr_library = expr_library[: int(config.max_library_size)]
    approx_total = 0
    for n_expr in range(1, int(config.max_expressions) + 1):
        approx_total += len(list(itertools.combinations(expr_library, n_expr))) * (len(config.weight_grid) ** n_expr)
    if config.max_candidates is not None and approx_total > int(config.max_candidates):
        warnings.warn(
            f"generate_symbolic_specs search space size≈{approx_total} exceeds max_candidates={config.max_candidates}; truncating generation budget.",
            RuntimeWarning,
            stacklevel=2,
        )
    specs: List[UtilitySpec] = []
    seen: set[tuple] = set()
    for n_expr in range(1, int(config.max_expressions) + 1):
        for exprs in itertools.combinations(expr_library, n_expr):
            for vals in itertools.product(config.weight_grid, repeat=n_expr):
                weights = {expr: float(val) for expr, val in zip(exprs, vals) if abs(float(val)) > 1e-12}
                if not weights:
                    continue
                key = tuple(sorted(weights.items()))
                if key in seen:
                    continue
                seen.add(key)
                specs.append(symbolic_spec(weights))
                if config.max_candidates is not None and len(specs) >= int(config.max_candidates):
                    return specs
    return specs


def candidate_complexity(candidate: PopulationCandidate) -> int:
    if not candidate.utility_specs:
        return 0
    return int(sum(UtilityModel.complexity(spec) for spec in candidate.utility_specs) / len(candidate.utility_specs))


def search_symbolic_utility(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    n_agents: int,
    test_env_builders: Dict[str, Callable[[], object]] | None = None,
    config: SymbolicSearchConfig | None = None,
    train_episodes: int = 48,
    seed: int = 0,
    weights: Dict[str, float] | None = None,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
    evaluate_top_k_on_test: int = 2,
) -> List[SearchResult]:
    config = config or SymbolicSearchConfig()
    target_train = split_target(target_moments, train_env_builders)
    target_val = split_target(target_moments, validation_env_builders)
    test_env_builders = test_env_builders or {}
    target_test = split_target(target_moments, test_env_builders)

    if getattr(config, "missing_moment_penalty", 1.0) != 1.0:
        warnings.warn(
            "SymbolicSearchConfig.missing_moment_penalty is deprecated and ignored; missing moments are handled internally by moment_loss.",
            DeprecationWarning,
            stacklevel=2,
        )

    specs = generate_symbolic_specs(config)
    if config.include_fixed_baselines:
        specs = fixed_baseline_specs() + specs

    results: List[SearchResult] = []
    for idx, spec in enumerate(specs):
        candidate = candidate_from_spec(spec, n_agents=n_agents)
        pred_train = evaluate_candidate(candidate, train_env_builders, train_episodes=train_episodes, seed=seed + idx * 31, agent_kind=agent_kind, tabular_config=tabular_config, deep_config=deep_config)
        pred_val = evaluate_candidate(candidate, validation_env_builders, train_episodes=train_episodes, seed=seed + idx * 31 + 777, agent_kind=agent_kind, tabular_config=tabular_config, deep_config=deep_config)
        train_loss = float(moment_loss(pred_train, target_train, weights=weights))
        validation_loss = float(moment_loss(pred_val, target_val, weights=weights))
        complexity = candidate_complexity(candidate)
        score = float(validation_loss + config.complexity_penalty * complexity)
        results.append(SearchResult(candidate, train_loss, validation_loss, None, complexity, score, pred_train, pred_val, None, selection_score=score, test_score=None, selection_basis="validation_loss"))
    results.sort(key=lambda r: r.score)

    if test_env_builders and evaluate_top_k_on_test > 0:
        for rank, result in enumerate(results[: int(evaluate_top_k_on_test)]):
            pred_test = evaluate_candidate(result.candidate, test_env_builders, train_episodes=train_episodes, seed=seed + 90000 + rank * 101, agent_kind=agent_kind, tabular_config=tabular_config, deep_config=deep_config)
            result.predicted_test = pred_test
            result.test_loss = float(moment_loss(pred_test, target_test, weights=weights)) if target_test else None
            result.test_score = (result.test_loss + result.complexity * float(config.complexity_penalty)) if result.test_loss is not None else None
    return results


def symbolic_results_to_frame(results: List[SearchResult]) -> pd.DataFrame:
    rows = []
    for r in results:
        row = {
            "candidate": r.candidate.name,
            "train_loss": r.train_loss,
            "validation_loss": r.validation_loss,
            "complexity": r.complexity,
            "score": r.score,
            "selection_score": r.selection_score,
            "selection_basis": r.selection_basis,
            "test_loss": r.test_loss,
            "test_score": r.test_score,
        }
        row.update({f"train::{k}": v for k, v in r.predicted_train.items()})
        row.update({f"val::{k}": v for k, v in r.predicted_validation.items()})
        if r.predicted_test is not None:
            row.update({f"test::{k}": v for k, v in r.predicted_test.items()})
        rows.append(row)
    return pd.DataFrame(rows)
