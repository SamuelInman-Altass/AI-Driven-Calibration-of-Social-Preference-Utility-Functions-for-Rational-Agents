from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Sequence

import numpy as np
import pandas as pd

from .agents import AgentConfig, DeepAgentConfig, UtilitySpec
from .calibration import PopulationCandidate, evaluate_candidate
from .utility_search import SearchConfig, SearchResult, search_best_utility, search_results_to_frame


def _extract_terms(spec: UtilitySpec) -> List[str]:
    if spec.family == "compositional":
        return list((spec.params.get("weights") or {}).keys())
    if spec.family == "social_tradeoff":
        return ["own_payoff", "others_mean"]
    if spec.family in {"inequity_aversion", "fehr_schmidt"}:
        return ["own_payoff", "disadv_ineq", "adv_ineq"]
    if spec.family == "selfish":
        return ["own_payoff"]
    return []


def _extract_weights(spec: UtilitySpec) -> Dict[str, float]:
    if spec.family == "compositional":
        return {str(k): float(v) for k, v in (spec.params.get("weights") or {}).items()}
    if spec.family == "social_tradeoff":
        return {"own_payoff": float(spec.params.get("selfish_weight", 1.0)), "others_mean": float(spec.params.get("altruism_weight", 0.0))}
    if spec.family in {"inequity_aversion", "fehr_schmidt"}:
        return {
            "own_payoff": float(spec.params.get("selfish_weight", 1.0)),
            "disadv_ineq": -float(spec.params.get("alpha", 0.8)),
            "adv_ineq": -float(spec.params.get("beta", 0.2)),
        }
    if spec.family == "selfish":
        return {"own_payoff": float(spec.params.get("selfish_weight", 1.0))}
    return {}


@dataclass
class BootstrapSummary:
    summary_frame: pd.DataFrame
    term_frequency: pd.DataFrame
    top1_frequency: pd.DataFrame


def bootstrap_search_stability(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    n_agents: int,
    n_bootstrap: int = 8,
    search_config: SearchConfig | None = None,
    include_fixed_baselines: bool = True,
    train_episodes: int = 48,
    base_seed: int = 0,
    weights: Dict[str, float] | None = None,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
) -> BootstrapSummary:
    rows: List[Dict[str, float | str | int]] = []
    term_counter: Counter[str] = Counter()
    candidate_counter: Counter[str] = Counter()

    for i in range(n_bootstrap):
        results = search_best_utility(
            target_moments=target_moments,
            train_env_builders=train_env_builders,
            validation_env_builders=validation_env_builders,
            test_env_builders=test_env_builders,
            n_agents=n_agents,
            search_config=search_config,
            include_fixed_baselines=include_fixed_baselines,
            train_episodes=train_episodes,
            seed=base_seed + 1009 * i,
            weights=weights,
            agent_kind=agent_kind,
            tabular_config=tabular_config,
            deep_config=deep_config,
            evaluate_top_k_on_test=2,
        )
        best = results[0]
        spec = best.candidate.utility_specs[0]
        candidate_counter[best.candidate.name] += 1
        for term in _extract_terms(spec):
            term_counter[term] += 1
        rows.append({
            "bootstrap_id": i,
            "candidate": best.candidate.name,
            "family": spec.family,
            "train_loss": best.train_loss,
            "validation_loss": best.validation_loss,
            "test_loss": best.test_loss if best.test_loss is not None else np.nan,
            "complexity": best.complexity,
            "score": best.score,
            "terms": ",".join(sorted(_extract_terms(spec))),
        })

    summary_frame = pd.DataFrame(rows)
    term_frequency = pd.DataFrame(
        [{"term": term, "selection_rate": count / max(n_bootstrap, 1), "count": count} for term, count in term_counter.items()]
    ).sort_values(["selection_rate", "term"], ascending=[False, True])
    top1_frequency = pd.DataFrame(
        [{"candidate": cand, "selection_rate": count / max(n_bootstrap, 1), "count": count} for cand, count in candidate_counter.items()]
    ).sort_values(["selection_rate", "candidate"], ascending=[False, True])
    return BootstrapSummary(summary_frame=summary_frame, term_frequency=term_frequency, top1_frequency=top1_frequency)


@dataclass
class OracleRecoveryResult:
    truth_family: str
    truth_terms: List[str]
    recovered_family: str
    recovered_terms: List[str]
    validation_loss: float
    test_loss: float | None
    structure_precision: float
    structure_recall: float
    weight_mae: float


def _structure_metrics(true_terms: Sequence[str], recovered_terms: Sequence[str]) -> tuple[float, float]:
    t = set(true_terms)
    r = set(recovered_terms)
    inter = len(t & r)
    precision = inter / max(len(r), 1)
    recall = inter / max(len(t), 1)
    return float(precision), float(recall)


def _weight_mae(truth: Dict[str, float], recovered: Dict[str, float]) -> float:
    keys = set(truth) | set(recovered)
    return float(np.mean([abs(float(truth.get(k, 0.0)) - float(recovered.get(k, 0.0))) for k in keys])) if keys else 0.0


def run_oracle_recovery_benchmark(
    truth_candidate: PopulationCandidate,
    train_env_builders: Dict[str, Callable[[], object]],
    validation_env_builders: Dict[str, Callable[[], object]],
    test_env_builders: Dict[str, Callable[[], object]] | None,
    n_agents: int,
    search_config: SearchConfig | None = None,
    train_episodes: int = 48,
    seed: int = 0,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
) -> tuple[Dict[str, float], SearchResult, OracleRecoveryResult, pd.DataFrame]:
    target_train = evaluate_candidate(truth_candidate, train_env_builders, train_episodes=train_episodes, seed=seed + 1, agent_kind=agent_kind, tabular_config=tabular_config, deep_config=deep_config)
    target_val = evaluate_candidate(truth_candidate, validation_env_builders, train_episodes=max(120, int(train_episodes * 0.8)), seed=seed + 2, agent_kind=agent_kind, tabular_config=tabular_config, deep_config=deep_config)
    target_test = evaluate_candidate(truth_candidate, test_env_builders, train_episodes=max(120, int(train_episodes * 0.8)), seed=seed + 3, agent_kind=agent_kind, tabular_config=tabular_config, deep_config=deep_config) if test_env_builders else {}
    target_moments = {**target_train, **target_val, **target_test}

    results = search_best_utility(
        target_moments=target_moments,
        train_env_builders=train_env_builders,
        validation_env_builders=validation_env_builders,
        test_env_builders=test_env_builders,
        n_agents=n_agents,
        search_config=search_config,
        include_fixed_baselines=True,
        train_episodes=max(140, int(train_episodes * 0.8)),
        seed=seed + 100,
        agent_kind=agent_kind,
        tabular_config=tabular_config,
        deep_config=deep_config,
        evaluate_top_k_on_test=2,
    )
    best = results[0]
    df = search_results_to_frame(results)

    truth_spec = truth_candidate.utility_specs[0]
    rec_spec = best.candidate.utility_specs[0]
    precision, recall = _structure_metrics(_extract_terms(truth_spec), _extract_terms(rec_spec))
    oracle = OracleRecoveryResult(
        truth_family=truth_spec.family,
        truth_terms=sorted(_extract_terms(truth_spec)),
        recovered_family=rec_spec.family,
        recovered_terms=sorted(_extract_terms(rec_spec)),
        validation_loss=float(best.validation_loss),
        test_loss=None if best.test_loss is None else float(best.test_loss),
        structure_precision=precision,
        structure_recall=recall,
        weight_mae=_weight_mae(_extract_weights(truth_spec), _extract_weights(rec_spec)),
    )
    return target_moments, best, oracle, df
