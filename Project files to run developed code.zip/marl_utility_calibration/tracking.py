from __future__ import annotations

from pathlib import Path
from typing import Callable, Dict, List

import numpy as np
import pandas as pd




def run_training_parallel_envs(env_builder: Callable[[], object], agents: Dict[str, object], episodes: int = 300, seed: int = 0, greedy_eval: bool = False, parallel_envs: int = 1) -> pd.DataFrame:
    if parallel_envs <= 1:
        env = env_builder()
        return run_training(env, agents, episodes=episodes, seed=seed, greedy_eval=greedy_eval)

    rows: List[dict] = []
    global_t = 0
    episode_cursor = 0
    agent_names = list(agents.keys())

    while episode_cursor < episodes:
        batch_size = min(parallel_envs, episodes - episode_cursor)
        states = []
        for local_idx in range(batch_size):
            env = env_builder()
            episode_id = episode_cursor + local_idx
            obs, infos = env.reset(seed=seed + episode_id)
            states.append({
                "env": env,
                "episode": episode_id,
                "obs": obs,
                "last_obs": {agent: obs[agent] for agent in env.possible_agents},
            })

        while any(state["env"].agents for state in states):
            batched_actions = [dict() for _ in states]
            for agent in agent_names:
                active = []
                obs_batch = []
                for idx, state in enumerate(states):
                    env = state["env"]
                    if agent in env.agents:
                        active.append(idx)
                        obs_batch.append(state["obs"][agent])
                if not active:
                    continue
                model = agents[agent]
                if hasattr(model, "act_many") and len(obs_batch) > 1:
                    chosen = model.act_many(np.stack(obs_batch), greedy=greedy_eval)
                    for env_idx, action in zip(active, chosen):
                        batched_actions[env_idx][agent] = int(action)
                else:
                    for env_idx, obs in zip(active, obs_batch):
                        batched_actions[env_idx][agent] = int(model.act(obs, greedy=greedy_eval))

            agents_with_batched_experience: set[str] = set()
            for state_idx, state in enumerate(states):
                env = state["env"]
                if not env.agents:
                    continue
                actions = batched_actions[state_idx]
                next_obs, rewards, terminations, truncations, infos = env.step(actions)
                active_agents = list(actions.keys())
                for agent in active_agents:
                    utility_reward = agents[agent].utility_reward(rewards, infos.get(agent, {}))
                    nxt = next_obs.get(agent, np.zeros_like(state["last_obs"][agent]))
                    done_flag = bool(terminations.get(agent, False) or truncations.get(agent, False))
                    model = agents[agent]
                    if not greedy_eval:
                        if hasattr(model, "add_experience") and hasattr(model, "train_step"):
                            model.add_experience(state["last_obs"][agent], actions[agent], utility_reward, nxt, done_flag)
                            agents_with_batched_experience.add(agent)
                        else:
                            model.update(state["last_obs"][agent], actions[agent], utility_reward, nxt, done_flag)
                    log_row = {
                        "episode": state["episode"],
                        "t": global_t,
                        "agent": agent,
                        "action": actions[agent],
                        "raw_reward": rewards.get(agent, 0.0),
                        "utility_reward": utility_reward,
                        "utility_family": agents[agent].utility_spec.family,
                        "agent_class": agents[agent].__class__.__name__,
                    }
                    if hasattr(agents[agent], "last_loss") and getattr(agents[agent], "last_loss") is not None:
                        log_row["last_loss"] = float(getattr(agents[agent], "last_loss"))
                    for k, v in infos.get(agent, {}).items():
                        log_row[k] = v
                    rows.append(log_row)
                    state["last_obs"][agent] = nxt
                state["obs"] = next_obs
                global_t += 1

            if not greedy_eval:
                for agent in sorted(agents_with_batched_experience):
                    model = agents[agent]
                    if hasattr(model, "add_experience") and hasattr(model, "train_step"):
                        model.train_step()

        episode_cursor += batch_size
    return pd.DataFrame(rows)



def _dedupe_ultimatum_rows(df: pd.DataFrame) -> pd.DataFrame:
    if "agent" in df.columns:
        agents = set(df["agent"].dropna().astype(str))
        if "proposer" in agents:
            return df[df["agent"].astype(str) == "proposer"].copy()
    subset = [c for c in ["episode", "t", "offer_frac", "accepted"] if c in df.columns]
    if subset:
        return df.drop_duplicates(subset=subset).copy()
    return df

MOMENT_KEYS = [
    "cooperation_rate",
    "mean_offer",
    "acceptance_rate",
    "mean_contribution",
    "mean_raw_reward",
]


def run_training(env, agents: Dict[str, object], episodes: int = 300, seed: int = 0, greedy_eval: bool = False) -> pd.DataFrame:
    rows: List[dict] = []
    global_t = 0
    for episode in range(episodes):
        obs, infos = env.reset(seed=seed + episode)
        last_obs = {agent: obs[agent] for agent in env.possible_agents}

        while env.agents:
            actions = {agent: agents[agent].act(obs[agent], greedy=greedy_eval) for agent in env.agents}
            next_obs, rewards, terminations, truncations, infos = env.step(actions)
            active_agents = list(actions.keys())
            for agent in active_agents:
                utility_reward = agents[agent].utility_reward(rewards, infos.get(agent, {}))
                nxt = next_obs.get(agent, np.zeros_like(last_obs[agent]))
                done_flag = bool(terminations.get(agent, False) or truncations.get(agent, False))
                if not greedy_eval:
                    agents[agent].update(last_obs[agent], actions[agent], utility_reward, nxt, done_flag)
                log_row = {
                    "episode": episode,
                    "t": global_t,
                    "agent": agent,
                    "action": actions[agent],
                    "raw_reward": rewards.get(agent, 0.0),
                    "utility_reward": utility_reward,
                    "utility_family": agents[agent].utility_spec.family,
                    "agent_class": agents[agent].__class__.__name__,
                }
                if hasattr(agents[agent], "last_loss") and getattr(agents[agent], "last_loss") is not None:
                    log_row["last_loss"] = float(getattr(agents[agent], "last_loss"))
                for k, v in infos.get(agent, {}).items():
                    log_row[k] = v
                rows.append(log_row)
                last_obs[agent] = nxt
            global_t += 1
            obs = next_obs
            done = {a: bool(terminations.get(a, False) or truncations.get(a, False)) for a in env.possible_agents}
            if all(done.values()):
                break
    return pd.DataFrame(rows)


def summarize_logs(df: pd.DataFrame) -> Dict[str, float]:
    out: Dict[str, float] = {k: np.nan for k in MOMENT_KEYS}
    if "cooperated" in df.columns:
        out["cooperation_rate"] = float(df["cooperated"].mean())
    stats_df = _dedupe_ultimatum_rows(df) if ("offer_frac" in df.columns or "accepted" in df.columns) else df
    if "offer_frac" in stats_df.columns:
        offer_rows = pd.to_numeric(stats_df["offer_frac"], errors="coerce").dropna()
        if len(offer_rows) > 0:
            out["mean_offer"] = float(offer_rows.mean())
    if "accepted" in stats_df.columns:
        accepted_rows = pd.to_numeric(stats_df["accepted"], errors="coerce").dropna()
        if len(accepted_rows) > 0:
            out["acceptance_rate"] = float(accepted_rows.mean())
    if "contribution_frac" in df.columns:
        out["mean_contribution"] = float(df["contribution_frac"].mean())
    if "raw_reward" in df.columns:
        out["mean_raw_reward"] = float(df["raw_reward"].mean())
    return out


def flatten_moments(moment_dict: Dict[str, Dict[str, float]]) -> Dict[str, float]:
    flat = {}
    for env_name, moments in moment_dict.items():
        for k, v in moments.items():
            flat[f"{env_name}::{k}"] = float(v) if not pd.isna(v) else np.nan
    return flat


def unflatten_moments(flat_moments: Dict[str, float]) -> Dict[str, Dict[str, float]]:
    nested: Dict[str, Dict[str, float]] = {}
    for key, value in flat_moments.items():
        if "::" not in key:
            continue
        env_name, moment_name = key.split("::", 1)
        nested.setdefault(env_name, {})[moment_name] = float(value)
    return nested


def moment_loss(
    predicted: Dict[str, float],
    target: Dict[str, float],
    weights: Dict[str, float] | None = None,
    missing_moment_penalty: float = 1.0,
) -> float:
    """Compute mean squared error over defined moment pairs only.

    Structurally undefined moments (for example acceptance_rate in RPD) are
    represented as NaN by the summarizers. These should be masked out rather
    than treated as model errors, otherwise heterogeneous environments incur a
    constant artificial penalty.

    The ``missing_moment_penalty`` argument is deprecated and ignored. Missing
    moment pairs are now handled by skipping NaN-defined metrics rather than
    applying any penalty.
    """
    import warnings

    if missing_moment_penalty != 1.0:
        warnings.warn(
            "`missing_moment_penalty` is deprecated and ignored; NaN-defined "
            "moment pairs are skipped rather than penalized.",
            DeprecationWarning,
            stacklevel=2,
        )

    weights = weights or {}
    loss = 0.0
    used = 0
    skipped: list[str] = []
    keys = set(predicted) & set(target)
    for key in keys:
        pv = predicted[key]
        tv = target[key]
        w = weights.get(key, 1.0)
        if np.isnan(pv) or np.isnan(tv):
            skipped.append(key)
            continue
        loss += float(w) * float((pv - tv) ** 2)
        used += 1
    if skipped:
        warnings.warn(
            f"moment_loss skipped {len(skipped)} NaN moment pairs as undefined metrics: {sorted(skipped)[:6]}",
            RuntimeWarning,
            stacklevel=2,
        )
    return float(loss / max(used, 1))


def empirical_logs_to_moments(df: pd.DataFrame) -> Dict[str, float]:
    required = {"env"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Empirical log data is missing required columns: {sorted(missing)}")

    per_env: Dict[str, Dict[str, float]] = {}
    for env_name, env_df in df.groupby("env"):
        stats: Dict[str, float] = {k: np.nan for k in MOMENT_KEYS}
        if "cooperated" in env_df.columns:
            stats["cooperation_rate"] = float(pd.to_numeric(env_df["cooperated"], errors="coerce").dropna().mean())
        stats_df = _dedupe_ultimatum_rows(env_df) if ("offer_frac" in env_df.columns or "accepted" in env_df.columns) else env_df
        if "offer_frac" in stats_df.columns:
            stats["mean_offer"] = float(pd.to_numeric(stats_df["offer_frac"], errors="coerce").dropna().mean())
        if "accepted" in stats_df.columns:
            stats["acceptance_rate"] = float(pd.to_numeric(stats_df["accepted"], errors="coerce").dropna().mean())
        if "contribution_frac" in env_df.columns:
            stats["mean_contribution"] = float(pd.to_numeric(env_df["contribution_frac"], errors="coerce").dropna().mean())
        if "raw_reward" in env_df.columns:
            stats["mean_raw_reward"] = float(pd.to_numeric(env_df["raw_reward"], errors="coerce").dropna().mean())
        per_env[str(env_name)] = stats
    return flatten_moments(per_env)


def load_empirical_targets(csv_path: str | Path) -> Dict[str, float]:
    path = Path(csv_path)
    df = pd.read_csv(path)

    if {"moment_key", "value"}.issubset(df.columns):
        return {str(k): float(v) for k, v in zip(df["moment_key"], df["value"])}

    if {"env", "moment", "value"}.issubset(df.columns):
        return {f"{env}::{moment}": float(value) for env, moment, value in zip(df["env"], df["moment"], df["value"])}

    if "env" in df.columns:
        return empirical_logs_to_moments(df)

    raise ValueError(
        "CSV format not recognized. Use one of: "
        "(1) columns moment_key,value; "
        "(2) columns env,moment,value; "
        "(3) trial-level logs with an env column and behavioral columns like cooperated, offer_frac, accepted, contribution_frac."
    )
