from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
import ast
from typing import Dict, Iterable, List, Sequence

import numpy as np


BASE_FEATURES: tuple[str, ...] = (
    "own_payoff",
    "others_mean",
    "others_sum",
    "others_min",
    "others_max",
    "disadv_ineq",
    "adv_ineq",
    "inequality_mean_abs",
    "accepted",
    "cooperated",
    "contribution_frac",
    "offer_frac",
)

UNARY_TEMPLATES: tuple[str, ...] = (
    "{x}",
    "neg({x})",
    "square({x})",
    "abs({x})",
    "pos({x})",
)

BINARY_TEMPLATES: tuple[str, ...] = (
    "mul({x},{y})",
    "min({x},{y})",
    "max({x},{y})",
)


def _safe_div(a: float, b: float) -> float:
    return float(a / b) if abs(b) > 1e-8 else 0.0


def expression_namespace(features: Dict[str, float]) -> Dict[str, object]:
    namespace: Dict[str, object] = {k: float(v) for k, v in features.items()}
    namespace.update(
        {
            "neg": lambda x: -float(x),
            "square": lambda x: float(x) * float(x),
            "abs": lambda x: abs(float(x)),
            "pos": lambda x: max(float(x), 0.0),
            "min": lambda x, y: float(np.minimum(float(x), float(y))),
            "max": lambda x, y: float(np.maximum(float(x), float(y))),
            "mul": lambda x, y: float(x) * float(y),
            "ratio": lambda x, y: _safe_div(float(x), float(y)),
        }
    )
    return namespace


def _eval_ast(node: ast.AST, namespace: Dict[str, object]) -> float:
    if isinstance(node, ast.Expression):
        return _eval_ast(node.body, namespace)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)
    if isinstance(node, ast.Name):
        value = namespace.get(node.id, 0.0)
        return float(value) if isinstance(value, (int, float, np.floating)) else 0.0
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
        fn = namespace.get(node.func.id)
        if fn is None or not callable(fn):
            raise ValueError(f"Unsupported function: {node.func.id}")
        args = [_eval_ast(arg, namespace) for arg in node.args]
        return float(fn(*args))
    if isinstance(node, ast.UnaryOp):
        x = _eval_ast(node.operand, namespace)
        if isinstance(node.op, ast.USub):
            return -x
        if isinstance(node.op, ast.UAdd):
            return x
        raise ValueError("Unsupported unary operator")
    if isinstance(node, ast.BinOp):
        a = _eval_ast(node.left, namespace)
        b = _eval_ast(node.right, namespace)
        if isinstance(node.op, ast.Add):
            return a + b
        if isinstance(node.op, ast.Sub):
            return a - b
        if isinstance(node.op, ast.Mult):
            return a * b
        if isinstance(node.op, ast.Div):
            return _safe_div(a, b)
        raise ValueError("Unsupported binary operator")
    raise ValueError("Unsupported expression node")


def evaluate_expression(expr: str, features: Dict[str, float]) -> float:
    try:
        parsed = ast.parse(expr, mode="eval")
        value = _eval_ast(parsed, expression_namespace(features))
        value = float(value)
        if not np.isfinite(value):
            return 0.0
        return float(np.clip(value, -10.0, 10.0))
    except Exception:
        return 0.0


def build_expression_library(
    base_features: Sequence[str] = BASE_FEATURES,
    unary_templates: Sequence[str] = UNARY_TEMPLATES,
    binary_templates: Sequence[str] = BINARY_TEMPLATES,
    include_ratio: bool = False,
) -> List[str]:
    exprs: List[str] = []
    seen: set[str] = set()
    for feature in base_features:
        for template in unary_templates:
            expr = template.format(x=feature)
            if expr not in seen:
                seen.add(expr)
                exprs.append(expr)
    for x, y in combinations(base_features, 2):
        for template in binary_templates:
            expr = template.format(x=x, y=y)
            if expr not in seen:
                seen.add(expr)
                exprs.append(expr)
        if include_ratio:
            for expr in (f"ratio({x},{y})", f"ratio({y},{x})"):
                if expr not in seen:
                    seen.add(expr)
                    exprs.append(expr)
    return exprs


def active_expression_count(weights: Dict[str, float], tol: float = 1e-12) -> int:
    return int(sum(1 for v in weights.values() if abs(float(v)) > tol))



def sample_feature_dicts(n_samples: int = 256, seed: int = 0, base_features: Sequence[str] = BASE_FEATURES) -> List[Dict[str, float]]:
    """Sample plausible normalized feature dictionaries for utility distillation/search."""
    rng = np.random.default_rng(seed)
    rows: List[Dict[str, float]] = []
    for _ in range(int(n_samples)):
        own = float(rng.uniform(0.0, 1.0))
        others = rng.uniform(0.0, 1.0, size=3)
        row = {
            "own_payoff": own,
            "others_mean": float(np.mean(others)),
            "others_sum": float(np.sum(others)),
            "others_min": float(np.min(others)),
            "others_max": float(np.max(others)),
            "disadv_ineq": float(np.maximum(others - own, 0.0).sum()),
            "adv_ineq": float(np.maximum(own - others, 0.0).sum()),
            "inequality_mean_abs": float(np.mean(np.abs(others - own))),
            "accepted": float(rng.integers(0, 2)),
            "cooperated": float(rng.integers(0, 2)),
            "contribution_frac": float(rng.uniform(0.0, 1.0)),
            "offer_frac": float(rng.uniform(0.0, 1.0)),
        }
        rows.append({k: float(row.get(k, 0.0)) for k in base_features})
    return rows


def expression_matrix(expressions: Sequence[str], feature_rows: Sequence[Dict[str, float]]) -> np.ndarray:
    if not expressions:
        return np.zeros((len(feature_rows), 0), dtype=float)
    cols = []
    for expr in expressions:
        cols.append([evaluate_expression(expr, row) for row in feature_rows])
    return np.asarray(cols, dtype=float).T
