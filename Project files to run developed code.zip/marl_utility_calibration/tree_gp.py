from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd

from .agents import AgentConfig, DeepAgentConfig, UtilitySpec, UtilityModel
from .calibration import PopulationCandidate, evaluate_candidate
from .tracking import moment_loss
from .utility_expressions import BASE_FEATURES, sample_feature_dicts

FEATURES: tuple[str, ...] = BASE_FEATURES
UNARY_OPS: tuple[str, ...] = ("neg", "abs", "square", "pos")
BINARY_OPS: tuple[str, ...] = ("add", "sub", "mul", "min", "max")


@dataclass(frozen=True)
class GPConfig:
    features: Sequence[str] = FEATURES
    population_size: int = 4
    generations: int = 1
    tournament_size: int = 2
    max_depth: int = 3
    mutation_rate: float = 0.35
    crossover_rate: float = 0.6
    elitism: int = 2
    constant_prob: float = 0.15
    complexity_penalty: float = 0.03
    parsimony_decay: float = 0.98
    distill_samples: int = 128


@dataclass
class GPResult:
    candidate: PopulationCandidate
    tree: Dict[str, Any]
    train_loss: float
    validation_loss: float
    test_loss: float | None
    complexity: int
    score: float
    base_selection_loss: float
    applied_complexity_penalty: float
    predicted_train: Dict[str, float]
    predicted_validation: Dict[str, float]
    predicted_test: Dict[str, float] | None


def _safe_float(x: Any) -> float:
    try:
        val = float(x)
        if not np.isfinite(val):
            return 0.0
        return float(np.clip(val, -10.0, 10.0))
    except Exception:
        return 0.0


def random_tree(rng: np.random.Generator, max_depth: int, features: Sequence[str], constant_prob: float = 0.15) -> Dict[str, Any]:
    if max_depth <= 0 or rng.random() < 0.30:
        if rng.random() < constant_prob:
            return {"type": "const", "value": float(rng.normal(0.0, 1.0))}
        return {"type": "feature", "name": str(rng.choice(list(features)))}
    if rng.random() < 0.35:
        op = str(rng.choice(UNARY_OPS))
        return {"type": "unary", "op": op, "child": random_tree(rng, max_depth - 1, features, constant_prob)}
    op = str(rng.choice(BINARY_OPS))
    return {
        "type": "binary",
        "op": op,
        "left": random_tree(rng, max_depth - 1, features, constant_prob),
        "right": random_tree(rng, max_depth - 1, features, constant_prob),
    }


def tree_to_string(tree: Dict[str, Any]) -> str:
    t = tree.get("type")
    if t == "const":
        return f"{float(tree.get('value', 0.0)):.3g}"
    if t == "feature":
        return str(tree.get("name", "own_payoff"))
    if t == "unary":
        return f"{tree.get('op')}({tree_to_string(tree.get('child', {}))})"
    if t == "binary":
        return f"{tree.get('op')}({tree_to_string(tree.get('left', {}))},{tree_to_string(tree.get('right', {}))})"
    return "0"


def eval_tree(tree: Dict[str, Any], features: Dict[str, float]) -> float:
    t = tree.get("type")
    if t == "const":
        return _safe_float(tree.get("value", 0.0))
    if t == "feature":
        return _safe_float(features.get(str(tree.get("name", "")), 0.0))
    if t == "unary":
        x = eval_tree(tree.get("child", {}), features)
        op = tree.get("op")
        if op == "neg":
            return -x
        if op == "abs":
            return abs(x)
        if op == "square":
            return _safe_float(x * x)
        if op == "pos":
            return max(x, 0.0)
        return 0.0
    if t == "binary":
        a = eval_tree(tree.get("left", {}), features)
        b = eval_tree(tree.get("right", {}), features)
        op = tree.get("op")
        if op == "add":
            return _safe_float(a + b)
        if op == "sub":
            return _safe_float(a - b)
        if op == "mul":
            return _safe_float(a * b)
        if op == "min":
            return _safe_float(min(a, b))
        if op == "max":
            return _safe_float(max(a, b))
        return 0.0
    return 0.0


def tree_complexity(tree: Dict[str, Any]) -> int:
    t = tree.get("type")
    if t in {"const", "feature"}:
        return 1
    if t == "unary":
        return 1 + tree_complexity(tree.get("child", {}))
    if t == "binary":
        return 1 + tree_complexity(tree.get("left", {})) + tree_complexity(tree.get("right", {}))
    return 1


def clone_tree(tree: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(tree, dict):
        return {k: clone_tree(v) for k, v in tree.items()}
    if isinstance(tree, list):
        return [clone_tree(v) for v in tree]
    return tree


def _collect_paths(tree: Dict[str, Any], prefix: Tuple[Any, ...] = ()) -> List[Tuple[Any, ...]]:
    paths = [prefix]
    t = tree.get("type")
    if t == "unary":
        paths.extend(_collect_paths(tree.get("child", {}), prefix + ("child",)))
    elif t == "binary":
        paths.extend(_collect_paths(tree.get("left", {}), prefix + ("left",)))
        paths.extend(_collect_paths(tree.get("right", {}), prefix + ("right",)))
    return paths


def _get_subtree(tree: Dict[str, Any], path: Tuple[Any, ...]) -> Dict[str, Any]:
    node = tree
    for key in path:
        node = node[key]
    return node


def _set_subtree(tree: Dict[str, Any], path: Tuple[Any, ...], subtree: Dict[str, Any]) -> Dict[str, Any]:
    if not path:
        return clone_tree(subtree)
    out = clone_tree(tree)
    node = out
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = clone_tree(subtree)
    return out


def mutate_tree(tree: Dict[str, Any], rng: np.random.Generator, cfg: GPConfig) -> Dict[str, Any]:
    paths = _collect_paths(tree)
    path = paths[int(rng.integers(len(paths)))]
    subtree = _get_subtree(tree, path)
    if subtree.get("type") == "const" and rng.random() < 0.5:
        new_sub = {"type": "const", "value": float(_safe_float(subtree.get("value", 0.0) + rng.normal(0.0, 0.5)))}
    elif subtree.get("type") == "feature" and rng.random() < 0.4:
        new_sub = {"type": "feature", "name": str(rng.choice(list(cfg.features)))}
    else:
        remaining_depth = max(0, cfg.max_depth - len(path))
        new_sub = random_tree(rng, remaining_depth, cfg.features, cfg.constant_prob)
    return _set_subtree(tree, path, new_sub)


def crossover_trees(a: Dict[str, Any], b: Dict[str, Any], rng: np.random.Generator, cfg: GPConfig) -> Dict[str, Any]:
    paths_a = _collect_paths(a)
    paths_b = _collect_paths(b)
    pa = paths_a[int(rng.integers(len(paths_a)))]
    pb = paths_b[int(rng.integers(len(paths_b)))]
    sub_b = _get_subtree(b, pb)
    child = _set_subtree(a, pa, sub_b)
    if tree_complexity(child) > (2 ** (cfg.max_depth + 1)):
        return mutate_tree(a, rng, cfg)
    return child


def gp_spec(tree: Dict[str, Any]) -> UtilitySpec:
    return UtilitySpec("gp_symbolic", {"tree": clone_tree(tree)})


def _split_targets(target_moments: Dict[str, float], train_envs, validation_envs, test_envs=None):
    train = {k: v for k, v in target_moments.items() if any(k.startswith(f"{name}::") for name in train_envs.keys())}
    val = {k: v for k, v in target_moments.items() if any(k.startswith(f"{name}::") for name in validation_envs.keys())}
    test_envs = test_envs or {}
    test = {k: v for k, v in target_moments.items() if any(k.startswith(f"{name}::") for name in test_envs.keys())}
    return train, val, test


def _candidate_from_tree(tree: Dict[str, Any], n_agents: int, prefix: str = "gp") -> PopulationCandidate:
    spec = gp_spec(tree)
    short = tree_to_string(tree)
    name = f"{prefix}_{short[:80]}"
    return PopulationCandidate(name=name, utility_specs=[spec for _ in range(n_agents)])


def _evaluate_tree(
    tree: Dict[str, Any],
    target_train: Dict[str, float],
    target_val: Dict[str, float],
    target_test: Dict[str, float],
    train_env_builders: Dict[str, Any],
    validation_env_builders: Dict[str, Any],
    test_env_builders: Dict[str, Any] | None,
    n_agents: int,
    train_episodes: int,
    seed: int,
    weights: Dict[str, float] | None,
    agent_kind: str,
    tabular_config: AgentConfig | None,
    deep_config: DeepAgentConfig | None,
    complexity_penalty: float,
) -> GPResult:
    candidate = _candidate_from_tree(tree, n_agents=n_agents)
    pred_train = evaluate_candidate(candidate, train_env_builders, train_episodes=train_episodes, seed=seed, agent_kind=agent_kind, tabular_config=tabular_config, deep_config=deep_config)
    pred_val = evaluate_candidate(candidate, validation_env_builders, train_episodes=train_episodes, seed=seed + 777, agent_kind=agent_kind, tabular_config=tabular_config, deep_config=deep_config)
    train_loss = float(moment_loss(pred_train, target_train, weights=weights))
    val_loss = float(moment_loss(pred_val, target_val, weights=weights))
    pred_test = None
    test_loss = None
    if test_env_builders:
        pred_test = evaluate_candidate(candidate, test_env_builders, train_episodes=train_episodes, seed=seed + 1555, agent_kind=agent_kind, tabular_config=tabular_config, deep_config=deep_config)
        test_loss = float(moment_loss(pred_test, target_test, weights=weights)) if target_test else None
    complexity = tree_complexity(tree)
    base_selection_loss = float(val_loss)
    score = float(base_selection_loss + complexity_penalty * complexity)
    return GPResult(
        candidate,
        clone_tree(tree),
        train_loss,
        val_loss,
        test_loss,
        complexity,
        score,
        base_selection_loss,
        float(complexity_penalty),
        pred_train,
        pred_val,
        pred_test,
    )


def tournament_select(results: Sequence[GPResult], rng: np.random.Generator, k: int) -> GPResult:
    idx = rng.choice(len(results), size=min(k, len(results)), replace=False)
    subset = [results[int(i)] for i in idx]
    subset.sort(key=lambda r: r.score)
    return subset[0]


def genetic_programming_search(
    target_moments: Dict[str, float],
    train_env_builders: Dict[str, Any],
    validation_env_builders: Dict[str, Any],
    test_env_builders: Dict[str, Any] | None,
    n_agents: int,
    config: GPConfig | None = None,
    train_episodes: int = 36,
    seed: int = 0,
    weights: Dict[str, float] | None = None,
    agent_kind: str = "tabular",
    tabular_config: AgentConfig | None = None,
    deep_config: DeepAgentConfig | None = None,
) -> List[GPResult]:
    cfg = config or GPConfig()
    target_train, target_val, target_test = _split_targets(target_moments, train_env_builders, validation_env_builders, test_env_builders)
    rng = np.random.default_rng(seed)
    population = [random_tree(rng, cfg.max_depth, cfg.features, cfg.constant_prob) for _ in range(cfg.population_size)]
    archive: List[GPResult] = []
    current_penalty = float(cfg.complexity_penalty)
    for gen in range(cfg.generations):
        scored: List[GPResult] = []
        for i, tree in enumerate(population):
            res = _evaluate_tree(tree, target_train, target_val, target_test, train_env_builders, validation_env_builders, test_env_builders, n_agents, train_episodes, seed + gen * 1000 + i, weights, agent_kind, tabular_config, deep_config, current_penalty)
            scored.append(res)
        scored.sort(key=lambda r: r.score)
        archive.extend(scored[: max(2, cfg.elitism)])
        elites = scored[: max(2, cfg.elitism)]
        next_pop = [clone_tree(r.tree) for r in elites]
        while len(next_pop) < cfg.population_size:
            parent_a = tournament_select(scored, rng, cfg.tournament_size).tree
            child = clone_tree(parent_a)
            if rng.random() < cfg.crossover_rate:
                parent_b = tournament_select(scored, rng, cfg.tournament_size).tree
                child = crossover_trees(child, parent_b, rng, cfg)
            if rng.random() < cfg.mutation_rate:
                child = mutate_tree(child, rng, cfg)
            next_pop.append(child)
        population = next_pop[: cfg.population_size]
        current_penalty *= float(cfg.parsimony_decay)
    rescored_archive: List[GPResult] = []
    for r in archive:
        rescored_archive.append(GPResult(
            candidate=r.candidate,
            tree=clone_tree(r.tree),
            train_loss=r.train_loss,
            validation_loss=r.validation_loss,
            test_loss=r.test_loss,
            complexity=r.complexity,
            score=float(r.base_selection_loss + float(cfg.complexity_penalty) * r.complexity),
            base_selection_loss=r.base_selection_loss,
            applied_complexity_penalty=float(cfg.complexity_penalty),
            predicted_train=r.predicted_train,
            predicted_validation=r.predicted_validation,
            predicted_test=r.predicted_test,
        ))
    rescored_archive.sort(key=lambda r: r.score)
    dedup: List[GPResult] = []
    seen = set()
    for r in rescored_archive:
        key = tree_to_string(r.tree)
        if key in seen:
            continue
        seen.add(key)
        dedup.append(r)
    return dedup


def distill_gp_tree_to_linear_weights(tree: Dict[str, Any], feature_rows: Sequence[Dict[str, float]] | None = None) -> Dict[str, Any]:
    feature_rows = list(feature_rows) if feature_rows is not None else sample_feature_dicts(n_samples=256, seed=0)
    if not feature_rows:
        return {"weights": {}, "distillation_mse": 0.0, "features_used": [], "dropped_collinear_features": []}

    all_features = list(feature_rows[0].keys())
    X_full = np.asarray([[float(row.get(feat, 0.0)) for feat in all_features] for row in feature_rows], dtype=float)
    y = np.asarray([eval_tree(tree, row) for row in feature_rows], dtype=float)

    selected_idx: List[int] = []
    dropped: List[str] = []
    current_rank = 0
    for idx, feat in enumerate(all_features):
        trial_idx = selected_idx + [idx]
        trial = X_full[:, trial_idx]
        rank = int(np.linalg.matrix_rank(trial))
        if rank > current_rank:
            selected_idx.append(idx)
            current_rank = rank
        else:
            dropped.append(feat)

    if not selected_idx:
        return {"weights": {}, "distillation_mse": float(np.mean(y ** 2)), "target_tree": tree_to_string(tree), "features_used": [], "dropped_collinear_features": dropped}

    features_used = [all_features[i] for i in selected_idx]
    X = X_full[:, selected_idx]
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ coef
    mse = float(np.mean((pred - y) ** 2))
    weights = {feat: float(c) for feat, c in zip(features_used, coef) if abs(float(c)) > 1e-9}
    return {
        "weights": weights,
        "distillation_mse": mse,
        "target_tree": tree_to_string(tree),
        "features_used": features_used,
        "dropped_collinear_features": dropped,
    }


def gp_results_to_frame(results: Sequence[GPResult]) -> pd.DataFrame:
    rows = []
    for r in results:
        row = {
            "candidate": r.candidate.name,
            "tree": tree_to_string(r.tree),
            "train_loss": r.train_loss,
            "validation_loss": r.validation_loss,
            "test_loss": r.test_loss,
            "complexity": r.complexity,
            "score": r.score,
        }
        rows.append(row)
    return pd.DataFrame(rows)
