from __future__ import annotations

from pathlib import Path
import json
import pandas as pd


def _maybe_read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def main():
    outdir = Path("outputs_predictive_optimality")
    if not outdir.exists():
        raise FileNotFoundError("outputs_predictive_optimality not found. Run demo_run_conference.py first.")

    ranking = _maybe_read_csv(outdir / "overall_ranking.csv")
    certs = _maybe_read_csv(outdir / "optimality_certificates.csv")
    rich = _maybe_read_csv(outdir / "rich_class_summary.csv")
    winners = _maybe_read_csv(outdir / "cross_method_winners.csv")
    restart_freq = _maybe_read_csv(outdir / "restart_winner_frequency.csv")
    consensus = _maybe_read_csv(outdir / "method_consensus_summary.csv")
    sig = _maybe_read_csv(outdir / "significance_table.csv")
    bootstrap = _maybe_read_csv(outdir / "bootstrap_summary.csv")
    finalists = _maybe_read_csv(outdir / "finalist_summary.csv")
    repeated = _maybe_read_csv(outdir / "finalist_repeated_test.csv")
    pairwise = _maybe_read_csv(outdir / "finalist_pairwise_tests.csv")
    winner_freq = _maybe_read_csv(outdir / "finalist_winner_frequency.csv")
    variance = _maybe_read_csv(outdir / "restart_variance_summary.csv")
    ablation = _maybe_read_csv(outdir / "ablation_summary.csv")

    print("Selected candidate:")
    print(ranking.iloc[0][["candidate", "signature", "family", "predictive_optimal_score", "mean_test_loss", "mean_validation_loss", "mean_complexity", "support"]].to_string())
    print("\nExact-vs-approximate summary:")
    print(rich.to_string(index=False))
    print("\nTop 10 overall ranking:")
    print(ranking.head(10).to_string(index=False))
    print("\nTop 10 certificates:")
    print(certs.head(10).to_string(index=False))
    print("\nCross-method winners by restart:")
    print(winners.to_string(index=False))
    if not restart_freq.empty:
        print("\nRestart winner frequency:")
        print(restart_freq.head(20).to_string(index=False))
    if not consensus.empty:
        print("\nMethod consensus summary:")
        print(consensus.head(20).to_string(index=False))
    if not sig.empty:
        print("\nBootstrap significance table:")
        print(sig.to_string(index=False))
    if not bootstrap.empty:
        print("\nBootstrap summary head:")
        print(bootstrap.head(20).to_string(index=False))
    if not finalists.empty:
        print("\nFinalist summary:")
        print(finalists.to_string(index=False))
    if not repeated.empty:
        print("\nFinalist repeated-test head:")
        print(repeated.head(20).to_string(index=False))
    if not pairwise.empty:
        print("\nFinalist pairwise tests:")
        print(pairwise.to_string(index=False))
    if not winner_freq.empty:
        print("\nFinalist winner frequency:")
        print(winner_freq.to_string(index=False))
    if not variance.empty:
        print("\nVariance across restarts/seeds (top 20):")
        print(variance.head(20).to_string(index=False))
    if not ablation.empty:
        print("\nAblation summary (top 20):")
        print(ablation.head(20).to_string(index=False))

    if (outdir / "conference_config.json").exists():
        print("\nConference configuration:")
        print(json.dumps(json.loads((outdir / "conference_config.json").read_text()), indent=2))


if __name__ == "__main__":
    main()
