from __future__ import annotations

from pathlib import Path

import pandas as pd

from marl_utility_calibration.agents import DeepAgentConfig, UtilitySpec
from marl_utility_calibration.calibration import PopulationCandidate, evaluate_candidate
from marl_utility_calibration.envs import build_public_goods_env, build_repeated_prisoners_dilemma_env, build_repeated_ultimatum_env
from marl_utility_calibration.predictive_optimality import PredictiveOptimalConfig, run_predictive_optimality_benchmark


def main():
    outdir = Path("outputs_predictive_optimality")
    outdir.mkdir(exist_ok=True)

    train_envs = {
        "rpd": lambda: build_repeated_prisoners_dilemma_env(horizon=8),
        "ult": lambda: build_repeated_ultimatum_env(rounds=6),
    }
    val_envs = {
        "pgg": lambda: build_public_goods_env(n_agents=3, horizon=6),
    }
    test_envs = {
        "rpd_shift": lambda: build_repeated_prisoners_dilemma_env(horizon=10, benefit=3.4),
        "ult_shift": lambda: build_repeated_ultimatum_env(rounds=7),
        "pgg_shift": lambda: build_public_goods_env(n_agents=3, horizon=7, multiplier=1.95),
    }

    deep_cfg = DeepAgentConfig(hidden_sizes=(64, 64), warmup_steps=64, replay_size=2500, batch_size=64, epsilon_decay=1500, device="auto", use_amp=True, compile_model=False)
    print(f"Using torch device: {deep_cfg.device}")

    # Use a homogeneous target population so recovery is evaluated within the same
    # representational scope searched by the benchmark methods.
    truth_spec = UtilitySpec(
        "social_tradeoff",
        {"selfish_weight": 1.0, "altruism_weight": 0.35, "other_payoff_aggregation": "mean"},
    )
    target_candidate = PopulationCandidate(
        name="predictive_truth_homogeneous_social_tradeoff",
        utility_specs=[truth_spec, truth_spec, truth_spec],
    )

    print("[demo] generating target moments", flush=True)
    target_moments = {}
    for env_name, builder in {**train_envs, **val_envs, **test_envs}.items():
        print(f"[demo] target env={env_name} start", flush=True)
        target_moments.update(evaluate_candidate(target_candidate, {env_name: builder}, train_episodes=24, seed=123, agent_kind="deep", deep_config=deep_cfg, verbose=True))
        print(f"[demo] target env={env_name} done total_target_moments={len(target_moments)}", flush=True)

    print("[demo] starting predictive optimality benchmark", flush=True)
    out = run_predictive_optimality_benchmark(
        target_moments=target_moments,
        train_env_builders=train_envs,
        validation_env_builders=val_envs,
        test_env_builders=test_envs,
        n_agents=3,
        config=PredictiveOptimalConfig(n_restarts=1, n_bootstrap=30, top_k_per_method=1, train_episodes=18, finalist_repeats=30),
        seed=42,
        agent_kind="deep",
        deep_config=deep_cfg,
    )

    (outdir / "approximate_predictive_optimality_definition.txt").write_text(out.definition)
    (outdir / "rich_class_interpretation.txt").write_text(out.rich_class_interpretation)
    pd.DataFrame([target_moments]).to_csv(outdir / "target_moments.csv", index=False)
    out.overall_ranking.to_csv(outdir / "overall_ranking.csv", index=False)
    out.bootstrap_summary.to_csv(outdir / "bootstrap_summary.csv", index=False)
    out.significance_table.to_csv(outdir / "significance_table.csv", index=False)
    out.exhaustive_restricted_ranking.to_csv(outdir / "exhaustive_restricted_ranking.csv", index=False)
    out.cross_method_winners.to_csv(outdir / "cross_method_winners.csv", index=False)
    out.agreement_summary.to_csv(outdir / "agreement_summary.csv", index=False)
    out.rich_class_summary.to_csv(outdir / "rich_class_summary.csv", index=False)
    out.optimality_certificates.to_csv(outdir / "optimality_certificates.csv", index=False)

    print(out.definition)
    print(out.rich_class_interpretation)
    print("\nSelected predictively optimal candidate:", out.selected_candidate)
    print("\nExact vs approximate summary")
    print(out.rich_class_summary.to_string(index=False))
    print("\nTop overall ranking")
    print(out.overall_ranking.head(10).to_string(index=False))
    print("\nTop certificates")
    print(out.optimality_certificates.head(10).to_string(index=False))
    print("\nSignificance table")
    print(out.significance_table.to_string(index=False))
    print("\nSaved outputs to", outdir.resolve())


if __name__ == "__main__":
    main()
