from __future__ import annotations

from pathlib import Path
import json

import pandas as pd
import torch

from marl_utility_calibration.agents import DeepAgentConfig, UtilitySpec
from marl_utility_calibration.calibration import PopulationCandidate, evaluate_candidate
from marl_utility_calibration.envs import (
    build_dictator_game_env,
    build_public_goods_env,
    build_repeated_prisoners_dilemma_env,
    build_repeated_ultimatum_env,
    build_sequential_trust_game_env,
)
from marl_utility_calibration.predictive_optimality import PredictiveOptimalConfig, run_predictive_optimality_benchmark


def _serialize_candidate(candidate: PopulationCandidate) -> dict:
    return {
        "name": candidate.name,
        "utility_specs": [
            {"family": spec.family, "params": spec.params}
            for spec in candidate.utility_specs
        ],
    }


def main():
    outdir = Path("outputs_predictive_optimality_ablations")
    outdir.mkdir(exist_ok=True)

    train_envs = {
        "rpd": lambda: build_repeated_prisoners_dilemma_env(horizon=8),
        "ult": lambda: build_repeated_ultimatum_env(rounds=6),
    }
    val_envs = {
        "pgg": lambda: build_public_goods_env(n_agents=3, horizon=6, multiplier=2.5),
        "dictator": lambda: build_dictator_game_env(rounds=6),
    }
    test_envs = {
        "rpd_shift": lambda: build_repeated_prisoners_dilemma_env(horizon=10, benefit=3.4),
        "ult_shift": lambda: build_repeated_ultimatum_env(rounds=7),
        "pgg_shift": lambda: build_public_goods_env(n_agents=3, horizon=7, multiplier=2.8),
        "dictator_shift": lambda: build_dictator_game_env(rounds=7, offer_levels=13),
        "trust_shift": lambda: build_sequential_trust_game_env(rounds=7, multiplier=3.2),
    }

    deep_cfg = DeepAgentConfig(
        hidden_sizes=(64, 64),
        warmup_steps=128,
        replay_size=6000,
        batch_size=128,
        epsilon_decay=1500,
        device="auto",
        use_amp=True,
        compile_model=torch.cuda.is_available(),
        parallel_envs=4 if torch.cuda.is_available() else 1,
    )

    truth_spec = UtilitySpec(
        "social_tradeoff",
        {"selfish_weight": 1.0, "altruism_weight": 1.0, "other_payoff_aggregation": "mean"},
    )
    target_candidate = PopulationCandidate(
        name="predictive_truth_homogeneous_social_tradeoff",
        utility_specs=[truth_spec, truth_spec, truth_spec],
    )

    cfg = PredictiveOptimalConfig(
        n_restarts=3,
        n_bootstrap=30,
        top_k_per_method=3,
        train_episodes=500,
        complexity_penalty=0.02,
        run_ablation_sweep=True,
        greedy_tail_frac=0.3,
        finalist_count=3,
    )

    meta = {
        "mode": "ablation_only",
        "target_generation_episodes": 500,
        "benchmark_config": {
            "n_restarts": cfg.n_restarts,
            "n_bootstrap": cfg.n_bootstrap,
            "top_k_per_method": cfg.top_k_per_method,
            "train_episodes": cfg.train_episodes,
            "complexity_penalty": cfg.complexity_penalty,
            "finalist_repeats": cfg.finalist_repeats,
            "finalist_eval_min_episodes": cfg.finalist_eval_min_episodes,
            "bootstrap_eval_min_episodes": cfg.bootstrap_eval_min_episodes,
            "greedy_tail_frac": cfg.greedy_tail_frac,
            "run_ablation_sweep": cfg.run_ablation_sweep,
        },
    }
    (outdir / "ablation_config.json").write_text(json.dumps(meta, indent=2))
    (outdir / "target_truth.json").write_text(json.dumps(_serialize_candidate(target_candidate), indent=2))

    print("[ablations] generating target moments", flush=True)
    target_moments = {}
    for env_name, builder in {**train_envs, **val_envs, **test_envs}.items():
        print(f"[ablations] target env={env_name} start", flush=True)
        target_moments.update(
            evaluate_candidate(
                target_candidate,
                {env_name: builder},
                train_episodes=500,
                seed=123,
                agent_kind="deep",
                deep_config=deep_cfg,
                verbose=True,
                greedy_tail_frac=cfg.greedy_tail_frac,
            )
        )
        print(f"[ablations] target env={env_name} done total_target_moments={len(target_moments)}", flush=True)

    print("[ablations] running benchmark for ablation outputs", flush=True)
    out = run_predictive_optimality_benchmark(
        target_moments=target_moments,
        train_env_builders=train_envs,
        validation_env_builders=val_envs,
        test_env_builders=test_envs,
        n_agents=3,
        config=cfg,
        seed=42,
        agent_kind="deep",
        deep_config=deep_cfg,
    )

    pd.DataFrame([target_moments]).to_csv(outdir / "target_moments.csv", index=False)
    out.ablation_summary.to_csv(outdir / "ablation_summary.csv", index=False)
    out.finalist_summary.to_csv(outdir / "finalist_summary.csv", index=False)
    out.overall_ranking.to_csv(outdir / "overall_ranking.csv", index=False)
    print("\nAblation summary")
    print(out.ablation_summary.head(20).to_string(index=False))
    print("\nSaved ablation outputs to", outdir.resolve())


if __name__ == "__main__":
    main()
